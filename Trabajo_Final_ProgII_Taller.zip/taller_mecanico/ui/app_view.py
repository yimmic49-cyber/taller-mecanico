"""Ventana principal: menú lateral (NavigationRail) y cambio de pantallas."""
from __future__ import annotations

from typing import List

import flet as ft

from data.categoria_dao import CategoriaDAO
from data.cliente_dao import ClienteDAO
from data.database_manager import RUTA_BD_POR_DEFECTO, DatabaseManager
from data.repuesto_repository import RepuestoRepository
from data.venta_repository import VentaRepository
from ui.components.categorias_view import CategoriasView
from ui.components.clientes_view import ClientesView
from ui.components.comunes import COLOR_ACENTO, Colors, Icons
from ui.components.repuestos_view import RepuestosView
from ui.components.resumen_view import ResumenView
from ui.components.ventas_view import VentasView
from ui.components.vista_base import VistaBase

NOMBRE_NEGOCIO = "Taller y Repuestos El Pistón"


class AppView:
    def __init__(self, page: ft.Page, ruta_bd: str = RUTA_BD_POR_DEFECTO) -> None:
        self.__page = page
        DatabaseManager.inicializar(ruta_bd)

        # Capa de datos (la UI solo conoce DAOs / Repositories, nunca SQL)
        cliente_dao = ClienteDAO(ruta_bd)
        categoria_dao = CategoriaDAO(ruta_bd)
        repuesto_repo = RepuestoRepository(ruta_bd)
        venta_repo = VentaRepository(ruta_bd)

        self.__configurar_pagina()
        self.__vistas: List[VistaBase] = [
            ResumenView(page, cliente_dao, repuesto_repo, venta_repo),
            ClientesView(page, cliente_dao),
            RepuestosView(page, repuesto_repo, categoria_dao),
            CategoriasView(page, categoria_dao),
            VentasView(page, venta_repo, cliente_dao, repuesto_repo),
        ]
        self.__contenido = ft.Container(content=self.__vistas[0].control, expand=True, padding=20)
        self.__menu = ft.NavigationRail(
            selected_index=0,
            label_type=ft.NavigationRailLabelType.ALL,
            min_width=100,
            leading=ft.Column([
                ft.Icon(Icons.CAR_REPAIR, size=40, color=COLOR_ACENTO),
                ft.Text("El Pistón", weight=ft.FontWeight.BOLD),
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
            destinations=[
                ft.NavigationRailDestination(icon=Icons.DASHBOARD_OUTLINED,
                                             selected_icon=Icons.DASHBOARD, label="Inicio"),
                ft.NavigationRailDestination(icon=Icons.PEOPLE_OUTLINE,
                                             selected_icon=Icons.PEOPLE, label="Clientes"),
                ft.NavigationRailDestination(icon=Icons.BUILD_OUTLINED,
                                             selected_icon=Icons.BUILD, label="Repuestos"),
                ft.NavigationRailDestination(icon=Icons.CATEGORY_OUTLINED,
                                             selected_icon=Icons.CATEGORY, label="Categorías"),
                ft.NavigationRailDestination(icon=Icons.POINT_OF_SALE_OUTLINED,
                                             selected_icon=Icons.POINT_OF_SALE, label="Ventas"),
            ],
            on_change=self.__cambiar_vista,
        )
        page.add(ft.Row([self.__menu, ft.VerticalDivider(width=1), self.__contenido], expand=True))
        self.__vistas[0].refrescar()

    def __configurar_pagina(self) -> None:
        p = self.__page
        p.title = f"{NOMBRE_NEGOCIO} - Sistema de gestión"
        p.theme_mode = ft.ThemeMode.LIGHT
        p.bgcolor = Colors.BLUE_GREY_50
        p.padding = 0
        try:  # Flet >= 0.24
            p.window.width, p.window.height = 1280, 800
            p.window.min_width, p.window.min_height = 1000, 650
        except AttributeError:  # versiones anteriores
            p.window_width, p.window_height = 1280, 800

    def __cambiar_vista(self, e) -> None:
        indice = int(e.control.selected_index)
        vista = self.__vistas[indice]
        self.__contenido.content = vista.control
        vista.refrescar()  # page.update() dentro de refrescar
