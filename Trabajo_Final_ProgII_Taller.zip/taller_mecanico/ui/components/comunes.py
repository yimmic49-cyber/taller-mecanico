"""Componentes y utilidades reutilizables de la interfaz Flet.

Incluye pequeñas funciones de compatibilidad para que la app funcione tanto en
Flet 0.2x como en Flet 0.8x / 1.x (algunos nombres cambiaron entre versiones).
"""
from __future__ import annotations

from typing import Callable, List, Optional

import flet as ft

# Compatibilidad de nombres entre versiones de Flet
Icons = getattr(ft, "Icons", None) or getattr(ft, "icons")
Colors = getattr(ft, "Colors", None) or getattr(ft, "colors")
_Opcion = getattr(ft, "DropdownOption", None) or ft.dropdown.Option

COLOR_PRIMARIO = Colors.BLUE_GREY_800
COLOR_ACENTO = Colors.ORANGE_700


def _borde(ancho: int, color):
    if hasattr(ft, "Border") and hasattr(ft.Border, "all"):
        return ft.Border.all(ancho, color)
    return ft.border.all(ancho, color)


def opcion(clave: str, texto: str):
    return _Opcion(key=clave, text=texto)


def abrir_dialogo(page: ft.Page, control) -> None:
    """Abre un AlertDialog o SnackBar sin importar la versión de Flet."""
    if hasattr(page, "show_dialog"):
        page.show_dialog(control)
    elif hasattr(page, "open"):
        page.open(control)
    else:  # versiones muy antiguas
        if isinstance(control, ft.SnackBar):
            page.snack_bar = control
        else:
            page.dialog = control
        control.open = True
        page.update()


def cerrar_dialogo(page: ft.Page, dialogo) -> None:
    if hasattr(page, "pop_dialog"):
        page.pop_dialog()
    elif hasattr(page, "close"):
        page.close(dialogo)
    else:
        dialogo.open = False
        page.update()


def notificar(page: ft.Page, mensaje: str, error: bool = False) -> None:
    barra = ft.SnackBar(
        content=ft.Text(mensaje, color=Colors.WHITE),
        bgcolor=Colors.RED_700 if error else Colors.GREEN_700,
    )
    abrir_dialogo(page, barra)


def confirmar(page: ft.Page, titulo: str, mensaje: str, al_aceptar: Callable[[], None]) -> None:
    """Muestra un diálogo Sí/No antes de ejecutar una acción destructiva."""
    dialogo: Optional[ft.AlertDialog] = None

    def aceptar(e):
        cerrar_dialogo(page, dialogo)
        al_aceptar()

    def cancelar(e):
        cerrar_dialogo(page, dialogo)

    dialogo = ft.AlertDialog(
        modal=True,
        title=ft.Text(titulo),
        content=ft.Text(mensaje),
        actions=[
            ft.TextButton(content=ft.Text("Cancelar"), on_click=cancelar),
            ft.FilledButton(content=ft.Text("Sí, continuar"), on_click=aceptar),
        ],
    )
    abrir_dialogo(page, dialogo)


def boton(texto: str, icono, al_hacer_clic, secundario: bool = False):
    """Botón con icono compatible con varias versiones de Flet."""
    contenido = ft.Row([ft.Icon(icono, size=18), ft.Text(texto)], spacing=6, tight=True)
    if secundario:
        return ft.OutlinedButton(content=contenido, on_click=al_hacer_clic)
    return ft.FilledButton(content=contenido, on_click=al_hacer_clic)


def titulo_seccion(texto: str, icono) -> ft.Row:
    return ft.Row([
        ft.Icon(icono, color=COLOR_ACENTO, size=30),
        ft.Text(texto, size=24, weight=ft.FontWeight.BOLD, color=COLOR_PRIMARIO),
    ])


def tarjeta(contenido, expand=False) -> ft.Container:
    return ft.Container(
        content=contenido,
        padding=15,
        border_radius=10,
        bgcolor=Colors.WHITE,
        border=_borde(1, Colors.BLUE_GREY_100),
        expand=expand,
    )


def crear_tabla(encabezados: List[str], numericas: Optional[List[int]] = None) -> ft.DataTable:
    numericas = numericas or []
    return ft.DataTable(
        columns=[
            ft.DataColumn(label=ft.Text(h, weight=ft.FontWeight.BOLD), numeric=(i in numericas))
            for i, h in enumerate(encabezados)
        ],
        rows=[],
        heading_row_color=Colors.BLUE_GREY_50,
        column_spacing=20,
    )


def celda(texto) -> ft.DataCell:
    return ft.DataCell(content=ft.Text(str(texto)))


def pesos(valor: float) -> str:
    return f"${valor:,.0f}".replace(",", ".")
