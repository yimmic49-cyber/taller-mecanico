"""Pantalla CRUD de categorías de repuestos."""
from __future__ import annotations

from typing import Optional

import flet as ft

from data.categoria_dao import CategoriaDAO
from data.errores import ErrorPersistencia
from domain.categoria import Categoria
from ui.components.comunes import (Colors, Icons, boton, celda, confirmar, crear_tabla, tarjeta,
                                   titulo_seccion)
from ui.components.vista_base import VistaBase


class CategoriasView(VistaBase):
    def __init__(self, page: ft.Page, dao: CategoriaDAO) -> None:
        self.__dao = dao
        self.__editando: Optional[Categoria] = None
        super().__init__(page)

    def _construir(self) -> ft.Control:
        self.txt_nombre = ft.TextField(label="Nombre *", width=220)
        self.txt_descripcion = ft.TextField(label="Descripción", width=420)
        self.lbl_modo = ft.Text("Nueva categoría", weight=ft.FontWeight.BOLD)
        self.tabla = crear_tabla(["ID", "Nombre", "Descripción", "Acciones"])
        return ft.Column([
            titulo_seccion("Categorías de repuestos", Icons.CATEGORY),
            tarjeta(ft.Column([
                self.lbl_modo,
                ft.Row([self.txt_nombre, self.txt_descripcion], wrap=True),
                ft.Row([
                    boton("Guardar", Icons.SAVE, self._guardar),
                    boton("Limpiar", Icons.CLEAR, lambda e: self._limpiar(), secundario=True),
                ]),
            ])),
            tarjeta(ft.Column([ft.Row([self.tabla], scroll=ft.ScrollMode.AUTO)],
                              scroll=ft.ScrollMode.AUTO, expand=True), expand=True),
        ], expand=True)

    def refrescar(self) -> None:
        self.tabla.rows.clear()
        for c in self.__dao.listar():
            self.tabla.rows.append(ft.DataRow(cells=[
                celda(c.id), celda(c.nombre), celda(c.descripcion),
                ft.DataCell(content=ft.Row([
                    ft.IconButton(icon=Icons.EDIT, icon_color=Colors.BLUE_600, tooltip="Editar",
                                  on_click=lambda e, cat=c: self._cargar(cat)),
                    ft.IconButton(icon=Icons.DELETE, icon_color=Colors.RED_600, tooltip="Eliminar",
                                  on_click=lambda e, cat=c: self._eliminar(cat)),
                ], spacing=0)),
            ]))
        self._actualizar()

    def _guardar(self, e) -> None:
        try:
            if self.__editando is None:
                categoria = Categoria(self.txt_nombre.value, self.txt_descripcion.value)
                self.__dao.crear(categoria)
                self._ok(f"Categoría {categoria} creada")
            else:
                self.__editando.nombre = self.txt_nombre.value
                self.__editando.descripcion = self.txt_descripcion.value
                self.__dao.actualizar(self.__editando)
                self._ok("Categoría actualizada")
            self._limpiar()
        except (ValueError, ErrorPersistencia) as ex:
            self._error(str(ex))

    def _cargar(self, categoria: Categoria) -> None:
        self.__editando = categoria
        self.txt_nombre.value = categoria.nombre
        self.txt_descripcion.value = categoria.descripcion
        self.lbl_modo.value = f"Editando categoría #{categoria.id}"
        self._actualizar()

    def _limpiar(self) -> None:
        self.__editando = None
        self.txt_nombre.value = ""
        self.txt_descripcion.value = ""
        self.lbl_modo.value = "Nueva categoría"
        self.refrescar()

    def _eliminar(self, categoria: Categoria) -> None:
        def ejecutar() -> None:
            try:
                self.__dao.eliminar(categoria.id)
                self._ok("Categoría eliminada")
                self._limpiar()
            except ErrorPersistencia as ex:
                self._error(str(ex))

        confirmar(self._page, "Eliminar categoría", f"¿Eliminar la categoría {categoria}?", ejecutar)
