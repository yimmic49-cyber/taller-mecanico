"""Pantalla CRUD del inventario de repuestos."""
from __future__ import annotations

from typing import Optional

import flet as ft

from data.categoria_dao import CategoriaDAO
from data.errores import ErrorPersistencia
from data.repuesto_repository import RepuestoRepository
from domain.repuesto import Repuesto
from ui.components.comunes import (Colors, Icons, boton, celda, confirmar, crear_tabla, opcion, pesos,
                                   tarjeta, titulo_seccion)
from ui.components.vista_base import VistaBase


class RepuestosView(VistaBase):
    def __init__(self, page: ft.Page, repo: RepuestoRepository, categoria_dao: CategoriaDAO) -> None:
        self.__repo = repo
        self.__categoria_dao = categoria_dao
        self.__editando: Optional[Repuesto] = None
        super().__init__(page)

    def _construir(self) -> ft.Control:
        self.txt_codigo = ft.TextField(label="Código *", width=130)
        self.txt_nombre = ft.TextField(label="Nombre del repuesto *", width=280)
        self.txt_marca = ft.TextField(label="Marca *", width=160)
        self.txt_precio = ft.TextField(label="Precio venta ($) *", width=150,
                                       keyboard_type=ft.KeyboardType.NUMBER)
        self.txt_stock = ft.TextField(label="Stock *", width=110, keyboard_type=ft.KeyboardType.NUMBER)
        self.dd_categoria = ft.Dropdown(label="Categoría *", width=220, options=[])
        self.lbl_modo = ft.Text("Nuevo repuesto", weight=ft.FontWeight.BOLD)

        self.txt_buscar = ft.TextField(label="Buscar por nombre, código o marca", width=320,
                                       prefix_icon=Icons.SEARCH, on_change=lambda e: self.refrescar())
        self.dd_filtro = ft.Dropdown(label="Filtrar categoría", width=200, options=[])
        self.tabla = crear_tabla(
            ["ID", "Código", "Repuesto", "Marca", "Categoría", "Precio", "Stock", "Acciones"],
            numericas=[5, 6])

        formulario = ft.Column([
            self.lbl_modo,
            ft.Row([self.txt_codigo, self.txt_nombre, self.txt_marca], wrap=True),
            ft.Row([self.txt_precio, self.txt_stock, self.dd_categoria], wrap=True),
            ft.Row([
                boton("Guardar", Icons.SAVE, self._guardar),
                boton("Limpiar", Icons.CLEAR, lambda e: self._limpiar(), secundario=True),
            ]),
        ])
        listado = ft.Column([
            ft.Row([
                self.txt_buscar, self.dd_filtro,
                boton("Filtrar", Icons.FILTER_ALT, lambda e: self.refrescar(), secundario=True),
                ft.Text("Las filas en rojo tienen stock bajo", italic=True, color=Colors.RED_400),
            ], wrap=True),
            ft.Column([ft.Row([self.tabla], scroll=ft.ScrollMode.AUTO)],
                      scroll=ft.ScrollMode.AUTO, expand=True),
        ], expand=True)
        return ft.Column([
            titulo_seccion("Inventario de repuestos", Icons.BUILD),
            tarjeta(formulario),
            tarjeta(listado, expand=True),
        ], expand=True)

    def _cargar_categorias(self) -> None:
        categorias = self.__categoria_dao.listar()
        self.dd_categoria.options = [opcion(str(c.id), c.nombre) for c in categorias]
        filtro_actual = self.dd_filtro.value
        self.dd_filtro.options = [opcion("0", "Todas")] + [opcion(str(c.id), c.nombre) for c in categorias]
        self.dd_filtro.value = filtro_actual or "0"

    def refrescar(self) -> None:
        self._cargar_categorias()
        categoria = int(self.dd_filtro.value) if self.dd_filtro.value not in (None, "", "0") else None
        self.tabla.rows.clear()
        for r in self.__repo.listar(self.txt_buscar.value or "", categoria):
            self.tabla.rows.append(ft.DataRow(
                color=Colors.RED_50 if r.stock_bajo else None,
                cells=[
                    celda(r.id), celda(r.codigo), celda(r.nombre), celda(r.marca),
                    celda(r.categoria_nombre), celda(pesos(r.precio)), celda(r.stock),
                    ft.DataCell(content=ft.Row([
                        ft.IconButton(icon=Icons.EDIT, icon_color=Colors.BLUE_600, tooltip="Editar",
                                      on_click=lambda e, rep=r: self._cargar(rep)),
                        ft.IconButton(icon=Icons.DELETE, icon_color=Colors.RED_600, tooltip="Eliminar",
                                      on_click=lambda e, rep=r: self._eliminar(rep)),
                    ], spacing=0)),
                ]))
        self._actualizar()

    def _guardar(self, e) -> None:
        try:
            if self.__editando is None:
                repuesto = Repuesto(self.txt_codigo.value, self.txt_nombre.value, self.txt_marca.value,
                                    self.txt_precio.value, self.txt_stock.value, self.dd_categoria.value)
                self.__repo.agregar(repuesto)
                self._ok(f"Repuesto {repuesto.codigo} agregado al inventario")
            else:
                r = self.__editando
                r.codigo = self.txt_codigo.value
                r.nombre = self.txt_nombre.value
                r.marca = self.txt_marca.value
                r.precio = self.txt_precio.value
                r.stock = self.txt_stock.value
                r.categoria_id = self.dd_categoria.value
                self.__repo.actualizar(r)
                self._ok(f"Repuesto {r.codigo} actualizado")
            self._limpiar()
        except (ValueError, ErrorPersistencia) as ex:
            self._error(str(ex))

    def _cargar(self, repuesto: Repuesto) -> None:
        self.__editando = repuesto
        self.txt_codigo.value = repuesto.codigo
        self.txt_nombre.value = repuesto.nombre
        self.txt_marca.value = repuesto.marca
        self.txt_precio.value = str(int(repuesto.precio))
        self.txt_stock.value = str(repuesto.stock)
        self.dd_categoria.value = str(repuesto.categoria_id)
        self.lbl_modo.value = f"Editando repuesto #{repuesto.id}"
        self._actualizar()

    def _limpiar(self) -> None:
        self.__editando = None
        for campo in (self.txt_codigo, self.txt_nombre, self.txt_marca, self.txt_precio, self.txt_stock):
            campo.value = ""
        self.dd_categoria.value = None
        self.lbl_modo.value = "Nuevo repuesto"
        self.refrescar()

    def _eliminar(self, repuesto: Repuesto) -> None:
        def ejecutar() -> None:
            try:
                self.__repo.eliminar(repuesto.id)
                self._ok("Repuesto eliminado")
                self._limpiar()
            except ErrorPersistencia as ex:
                self._error(str(ex))

        confirmar(self._page, "Eliminar repuesto", f"¿Eliminar {repuesto.nombre}?", ejecutar)
