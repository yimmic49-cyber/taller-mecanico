"""Pantalla de inicio: indicadores del taller y alertas de stock bajo."""
from __future__ import annotations

import flet as ft

from data.cliente_dao import ClienteDAO
from data.repuesto_repository import RepuestoRepository
from data.venta_repository import VentaRepository
from ui.components.comunes import (Colors, Icons, celda, crear_tabla, pesos, tarjeta,
                                   titulo_seccion)
from ui.components.vista_base import VistaBase


class ResumenView(VistaBase):
    def __init__(self, page: ft.Page, cliente_dao: ClienteDAO, repuesto_repo: RepuestoRepository,
                 venta_repo: VentaRepository) -> None:
        self.__cliente_dao = cliente_dao
        self.__repuesto_repo = repuesto_repo
        self.__venta_repo = venta_repo
        super().__init__(page)

    def _indicador(self, titulo: str, icono, color) -> ft.Container:
        valor = ft.Text("0", size=26, weight=ft.FontWeight.BOLD)
        caja = tarjeta(ft.Row([
            ft.Icon(icono, size=40, color=color),
            ft.Column([ft.Text(titulo, color=Colors.BLUE_GREY_600), valor], spacing=2),
        ]))
        caja.width = 260
        caja.data = valor  # referencia al Text para actualizarlo
        return caja

    def _construir(self) -> ft.Control:
        self.ind_clientes = self._indicador("Clientes", Icons.PEOPLE, Colors.BLUE_600)
        self.ind_repuestos = self._indicador("Referencias en inventario", Icons.BUILD, Colors.ORANGE_700)
        self.ind_inventario = self._indicador("Valor del inventario", Icons.INVENTORY, Colors.TEAL_600)
        self.ind_ventas = self._indicador("Total vendido", Icons.ATTACH_MONEY, Colors.GREEN_700)
        self.tabla_alertas = crear_tabla(["Código", "Repuesto", "Marca", "Stock"], numericas=[3])
        return ft.Column([
            titulo_seccion("Resumen del taller", Icons.DASHBOARD),
            ft.Row([self.ind_clientes, self.ind_repuestos, self.ind_inventario, self.ind_ventas],
                   wrap=True),
            tarjeta(ft.Column([
                ft.Row([ft.Icon(Icons.WARNING_AMBER, color=Colors.RED_600),
                        ft.Text("Repuestos con stock bajo: hay que pedir al proveedor",
                                weight=ft.FontWeight.BOLD)]),
                ft.Column([self.tabla_alertas], scroll=ft.ScrollMode.AUTO, expand=True),
            ], expand=True), expand=True),
        ], expand=True)

    def refrescar(self) -> None:
        self.ind_clientes.data.value = str(self.__cliente_dao.contar())
        self.ind_repuestos.data.value = str(self.__repuesto_repo.contar())
        self.ind_inventario.data.value = pesos(self.__repuesto_repo.valor_inventario())
        self.ind_ventas.data.value = (f"{pesos(self.__venta_repo.total_vendido())} "
                                      f"({self.__venta_repo.contar()} fact.)")
        self.tabla_alertas.rows.clear()
        for r in self.__repuesto_repo.listar_stock_bajo():
            self.tabla_alertas.rows.append(ft.DataRow(cells=[
                celda(r.codigo), celda(r.nombre), celda(r.marca), celda(r.stock)]))
        self._actualizar()
