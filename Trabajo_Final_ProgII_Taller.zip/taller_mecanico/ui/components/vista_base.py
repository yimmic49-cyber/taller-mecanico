"""Clase base para todas las pantallas (vistas) de la aplicación."""
from __future__ import annotations

from abc import ABC, abstractmethod

import flet as ft

from ui.components.comunes import notificar


class VistaBase(ABC):
    """Cada vista construye su propio árbol de controles (composición) y sabe
    refrescarse leyendo de los DAO/Repositories. La UI nunca escribe SQL."""

    def __init__(self, page: ft.Page) -> None:
        self._page: ft.Page = page
        self._control: ft.Control = self._construir()

    @property
    def control(self) -> ft.Control:
        return self._control

    @abstractmethod
    def _construir(self) -> ft.Control:
        """Crea los controles de la pantalla."""

    @abstractmethod
    def refrescar(self) -> None:
        """Recarga los datos desde la base de datos y actualiza la pantalla."""

    def _ok(self, mensaje: str) -> None:
        notificar(self._page, mensaje)

    def _error(self, mensaje: str) -> None:
        notificar(self._page, mensaje, error=True)

    def _actualizar(self) -> None:
        self._page.update()
