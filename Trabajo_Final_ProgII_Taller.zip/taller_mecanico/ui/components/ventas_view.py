"""Pantalla de facturación: venta de repuestos a clientes e historial."""
from __future__ import annotations

from typing import Dict, Optional

import flet as ft

from data.cliente_dao import ClienteDAO
from data.errores import ErrorPersistencia
from data.repuesto_repository import RepuestoRepository
from data.venta_repository import VentaRepository
from domain.repuesto import Repuesto
from domain.venta import DetalleVenta, Venta
from ui.components.comunes import (Colors, Icons, abrir_dialogo, boton, celda, cerrar_dialogo,
                                   confirmar, crear_tabla, opcion, pesos, tarjeta, titulo_seccion)
from ui.components.vista_base import VistaBase


class VentasView(VistaBase):
    def __init__(self, page: ft.Page, venta_repo: VentaRepository, cliente_dao: ClienteDAO,
                 repuesto_repo: RepuestoRepository) -> None:
        self.__venta_repo = venta_repo
        self.__cliente_dao = cliente_dao
        self.__repuesto_repo = repuesto_repo
        self.__repuestos: Dict[str, Repuesto] = {}
        self.__carrito: Optional[Venta] = None
        super().__init__(page)

    def _construir(self) -> ft.Control:
        self.dd_cliente = ft.Dropdown(label="Cliente *", width=300, options=[])
        self.dd_repuesto = ft.Dropdown(label="Repuesto *", width=380, options=[])
        self.txt_cantidad = ft.TextField(label="Cantidad", value="1", width=100,
                                         keyboard_type=ft.KeyboardType.NUMBER)
        self.tabla_carrito = crear_tabla(["Repuesto", "Cant.", "Precio unit.", "Subtotal", ""],
                                         numericas=[1, 2, 3])
        self.lbl_total = ft.Text("Total: $0", size=20, weight=ft.FontWeight.BOLD, color=Colors.GREEN_800)
        self.tabla_historial = crear_tabla(["N°", "Fecha", "Cliente", "Total", "Acciones"], numericas=[3])

        nueva_factura = ft.Column([
            ft.Text("Nueva factura", weight=ft.FontWeight.BOLD),
            ft.Row([self.dd_cliente], wrap=True),
            ft.Row([self.dd_repuesto, self.txt_cantidad,
                    boton("Agregar", Icons.ADD_SHOPPING_CART, self._agregar_al_carrito)], wrap=True),
            ft.Row([self.tabla_carrito], scroll=ft.ScrollMode.AUTO),
            ft.Row([
                self.lbl_total,
                boton("Registrar factura", Icons.POINT_OF_SALE, self._registrar),
                boton("Cancelar", Icons.CLEAR, lambda e: self._nuevo_carrito(), secundario=True),
            ], wrap=True, spacing=20),
        ], scroll=ft.ScrollMode.AUTO)
        historial = ft.Column([
            ft.Text("Historial de facturas", weight=ft.FontWeight.BOLD),
            ft.Column([ft.Row([self.tabla_historial], scroll=ft.ScrollMode.AUTO)],
                      scroll=ft.ScrollMode.AUTO, expand=True),
        ], expand=True)
        return ft.Column([
            titulo_seccion("Ventas / Facturación", Icons.POINT_OF_SALE),
            ft.Row([tarjeta(nueva_factura, expand=True), tarjeta(historial, expand=True)],
                   expand=True, vertical_alignment=ft.CrossAxisAlignment.START),
        ], expand=True)

    # ----- Carga de datos -----
    def refrescar(self) -> None:
        cliente_sel = self.dd_cliente.value
        self.dd_cliente.options = [opcion(str(c.id), str(c)) for c in self.__cliente_dao.listar()]
        self.dd_cliente.value = cliente_sel
        self.__repuestos = {str(r.id): r for r in self.__repuesto_repo.listar() if r.stock > 0}
        self.dd_repuesto.options = [
            opcion(k, f"{r.codigo} - {r.nombre} ({r.stock} disp.) {pesos(r.precio)}")
            for k, r in self.__repuestos.items()
        ]
        self._pintar_carrito()
        self._pintar_historial()
        self._actualizar()

    def _pintar_historial(self) -> None:
        self.tabla_historial.rows.clear()
        for v in self.__venta_repo.listar():
            self.tabla_historial.rows.append(ft.DataRow(cells=[
                celda(v.id), celda(v.fecha), celda(v.cliente_nombre), celda(pesos(v.total)),
                ft.DataCell(content=ft.Row([
                    ft.IconButton(icon=Icons.VISIBILITY, icon_color=Colors.BLUE_600, tooltip="Ver detalle",
                                  on_click=lambda e, ven=v: self._ver_detalle(ven.id)),
                    ft.IconButton(icon=Icons.DELETE, icon_color=Colors.RED_600,
                                  tooltip="Anular (devuelve el stock)",
                                  on_click=lambda e, ven=v: self._anular(ven)),
                ], spacing=0)),
            ]))

    # ----- Carrito -----
    def _lineas(self):
        return list(self.__carrito) if self.__carrito is not None else []

    def _pintar_carrito(self) -> None:
        self.tabla_carrito.rows.clear()
        for d in self._lineas():
            self.tabla_carrito.rows.append(ft.DataRow(cells=[
                celda(d.repuesto_nombre), celda(d.cantidad), celda(pesos(d.precio_unitario)),
                celda(pesos(d.subtotal)),
                ft.DataCell(content=ft.IconButton(
                    icon=Icons.REMOVE_CIRCLE, icon_color=Colors.RED_600, tooltip="Quitar",
                    on_click=lambda e, rid=d.repuesto_id: self._quitar(rid))),
            ]))
        total = self.__carrito() if self.__carrito is not None else 0
        self.lbl_total.value = f"Total: {pesos(total)}"

    def _agregar_al_carrito(self, e) -> None:
        try:
            if not self.dd_cliente.value:
                raise ValueError("Primero seleccione el cliente")
            repuesto = self.__repuestos.get(self.dd_repuesto.value or "")
            if repuesto is None:
                raise ValueError("Seleccione un repuesto")
            if self.__carrito is None or self.__carrito.cliente_id != int(self.dd_cliente.value):
                lineas_previas = self._lineas()
                self.__carrito = Venta(self.dd_cliente.value)
                for d in lineas_previas:
                    self.__carrito.agregar_detalle(d)
            detalle = DetalleVenta(repuesto.id, self.txt_cantidad.value, repuesto.precio,
                                   repuesto_nombre=repuesto.nombre)
            ya_en_carrito = sum(d.cantidad for d in self.__carrito if d.repuesto_id == repuesto.id)
            if ya_en_carrito + detalle.cantidad > repuesto.stock:
                raise ValueError(f"Solo hay {repuesto.stock} unidades de {repuesto.nombre}")
            self.__carrito.agregar_detalle(detalle)
            self.txt_cantidad.value = "1"
            self._pintar_carrito()
            self._actualizar()
        except ValueError as ex:
            self._error(str(ex))

    def _quitar(self, repuesto_id: int) -> None:
        if self.__carrito is not None:
            self.__carrito.quitar_detalle(repuesto_id)
        self._pintar_carrito()
        self._actualizar()

    def _nuevo_carrito(self) -> None:
        self.__carrito = None
        self.dd_repuesto.value = None
        self.txt_cantidad.value = "1"
        self.refrescar()

    # ----- Registrar / Ver / Anular -----
    def _registrar(self, e) -> None:
        try:
            if self.__carrito is None or len(self.__carrito) == 0:
                raise ValueError("Agregue al menos un repuesto a la factura")
            if str(self.__carrito.cliente_id) != str(self.dd_cliente.value):
                lineas = self._lineas()
                self.__carrito = Venta(self.dd_cliente.value)
                for d in lineas:
                    self.__carrito.agregar_detalle(d)
            venta = self.__venta_repo.registrar(self.__carrito)
            self._ok(f"Factura #{venta.id} registrada por {pesos(venta.total)}")
            self.dd_cliente.value = None
            self._nuevo_carrito()
        except (ValueError, ErrorPersistencia) as ex:
            self._error(str(ex))

    def _ver_detalle(self, id_venta: int) -> None:
        venta = self.__venta_repo.obtener_por_id(id_venta)
        if venta is None:
            return
        tabla = crear_tabla(["Repuesto", "Cant.", "Precio", "Subtotal"], numericas=[1, 2, 3])
        for d in venta:
            tabla.rows.append(ft.DataRow(cells=[
                celda(d.repuesto_nombre), celda(d.cantidad), celda(pesos(d.precio_unitario)),
                celda(pesos(d.subtotal))]))
        dialogo: Optional[ft.AlertDialog] = None
        dialogo = ft.AlertDialog(
            title=ft.Text(f"Factura #{venta.id}"),
            content=ft.Column([
                ft.Text(f"Cliente: {venta.cliente_nombre}"),
                ft.Text(f"Fecha: {venta.fecha}"),
                tabla,
                ft.Text(f"TOTAL: {pesos(venta.total)}  ({len(venta)} repuestos distintos)",
                        weight=ft.FontWeight.BOLD),
            ], tight=True, scroll=ft.ScrollMode.AUTO),
            actions=[ft.TextButton(content=ft.Text("Cerrar"),
                                   on_click=lambda e: cerrar_dialogo(self._page, dialogo))],
        )
        abrir_dialogo(self._page, dialogo)

    def _anular(self, venta: Venta) -> None:
        def ejecutar() -> None:
            try:
                self.__venta_repo.anular(venta.id)
                self._ok(f"Factura #{venta.id} anulada; stock devuelto al inventario")
                self.refrescar()
            except ErrorPersistencia as ex:
                self._error(str(ex))

        confirmar(self._page, "Anular factura",
                  f"¿Anular la factura #{venta.id} por {pesos(venta.total)}? "
                  "Las unidades vuelven al inventario.", ejecutar)
