"""Patrón Repository para ventas (facturas) y su detalle.

Registrar una venta toca 3 tablas (ventas, detalle_venta y repuestos) dentro de
UNA sola transacción: si algún repuesto no tiene stock suficiente se lanza una
excepción y DatabaseManager hace rollback() de todo.
"""
from __future__ import annotations

from typing import List, Optional

from data.database_manager import RUTA_BD_POR_DEFECTO, DatabaseManager
from data.errores import ErrorPersistencia
from domain.venta import DetalleVenta, Venta


class VentaRepository:
    def __init__(self, ruta_bd: str = RUTA_BD_POR_DEFECTO) -> None:
        self.__ruta_bd = ruta_bd

    def registrar(self, venta: Venta) -> Venta:
        if len(venta) == 0:
            raise ErrorPersistencia("La factura no tiene repuestos")
        with DatabaseManager(self.__ruta_bd) as db:
            db.ejecutar("INSERT INTO ventas (cliente_id, fecha, total) VALUES (?, ?, ?)",
                        venta.a_tupla())
            venta.id = db.ultimo_id
            for detalle in venta:
                detalle.venta_id = venta.id
                db.ejecutar(
                    "INSERT INTO detalle_venta (venta_id, repuesto_id, cantidad, precio_unitario) "
                    "VALUES (?, ?, ?, ?)", detalle.a_tupla())
                cursor = db.ejecutar(
                    "UPDATE repuestos SET stock = stock - ? WHERE id = ? AND stock >= ?",
                    (detalle.cantidad, detalle.repuesto_id, detalle.cantidad))
                if cursor.rowcount == 0:
                    # Provoca rollback automático en DatabaseManager.__exit__
                    raise ErrorPersistencia(
                        f"Stock insuficiente para '{detalle.repuesto_nombre or detalle.repuesto_id}'")
        return venta

    def listar(self) -> List[Venta]:
        with DatabaseManager(self.__ruta_bd) as db:
            filas = db.consultar_todos(
                "SELECT v.id, v.cliente_id, v.fecha, v.total, c.nombre "
                "FROM ventas v INNER JOIN clientes c ON c.id = v.cliente_id "
                "ORDER BY v.id DESC")
        return [Venta.desde_tupla(f) for f in filas]

    def obtener_detalle(self, id_venta: int) -> List[DetalleVenta]:
        with DatabaseManager(self.__ruta_bd) as db:
            filas = db.consultar_todos(
                "SELECT d.id, d.venta_id, d.repuesto_id, d.cantidad, d.precio_unitario, r.nombre "
                "FROM detalle_venta d INNER JOIN repuestos r ON r.id = d.repuesto_id "
                "WHERE d.venta_id = ?", (id_venta,))
        return [DetalleVenta.desde_tupla(f) for f in filas]

    def obtener_por_id(self, id_venta: int) -> Optional[Venta]:
        with DatabaseManager(self.__ruta_bd) as db:
            fila = db.consultar_uno(
                "SELECT v.id, v.cliente_id, v.fecha, v.total, c.nombre FROM ventas v "
                "INNER JOIN clientes c ON c.id = v.cliente_id WHERE v.id = ?", (id_venta,))
        if not fila:
            return None
        venta = Venta.desde_tupla(fila)
        for detalle in self.obtener_detalle(id_venta):
            venta.agregar_detalle(detalle)
        return venta

    def anular(self, id_venta: int) -> None:
        """Elimina la factura y devuelve las unidades al inventario (una transacción)."""
        with DatabaseManager(self.__ruta_bd) as db:
            detalles = db.consultar_todos(
                "SELECT repuesto_id, cantidad FROM detalle_venta WHERE venta_id = ?", (id_venta,))
            for repuesto_id, cantidad in detalles:
                db.ejecutar("UPDATE repuestos SET stock = stock + ? WHERE id = ?",
                            (cantidad, repuesto_id))
            # ON DELETE CASCADE borra las filas de detalle_venta
            db.ejecutar("DELETE FROM ventas WHERE id = ?", (id_venta,))

    def total_vendido(self) -> float:
        with DatabaseManager(self.__ruta_bd) as db:
            return db.consultar_uno("SELECT COALESCE(SUM(total), 0) FROM ventas")[0]

    def contar(self) -> int:
        with DatabaseManager(self.__ruta_bd) as db:
            return db.consultar_uno("SELECT COUNT(*) FROM ventas")[0]
