"""Patrón Repository para los repuestos (inventario del taller)."""
from __future__ import annotations

import sqlite3
from typing import List, Optional

from data.database_manager import RUTA_BD_POR_DEFECTO, DatabaseManager
from data.errores import traducir_integridad
from domain.repuesto import Repuesto

_SELECT_BASE = (
    "SELECT r.id, r.codigo, r.nombre, r.marca, r.precio, r.stock, r.categoria_id, c.nombre "
    "FROM repuestos r INNER JOIN categorias c ON c.id = r.categoria_id "
)


class RepuestoRepository:
    def __init__(self, ruta_bd: str = RUTA_BD_POR_DEFECTO) -> None:
        self.__ruta_bd = ruta_bd

    def agregar(self, repuesto: Repuesto) -> Repuesto:
        try:
            with DatabaseManager(self.__ruta_bd) as db:
                db.ejecutar(
                    "INSERT INTO repuestos (codigo, nombre, marca, precio, stock, categoria_id) "
                    "VALUES (?, ?, ?, ?, ?, ?)", repuesto.a_tupla())
                repuesto.id = db.ultimo_id
        except sqlite3.IntegrityError as e:
            raise traducir_integridad(e, "repuesto") from e
        return repuesto

    def listar(self, filtro: str = "", categoria_id: Optional[int] = None) -> List[Repuesto]:
        patron = f"%{filtro.strip()}%"
        sql = _SELECT_BASE + "WHERE (r.nombre LIKE ? OR r.codigo LIKE ? OR r.marca LIKE ?) "
        parametros: list = [patron, patron, patron]
        if categoria_id:
            sql += "AND r.categoria_id = ? "
            parametros.append(categoria_id)
        sql += "ORDER BY r.nombre"
        with DatabaseManager(self.__ruta_bd) as db:
            filas = db.consultar_todos(sql, parametros)
        return [Repuesto.desde_tupla(f) for f in filas]

    def obtener_por_id(self, id_repuesto: int) -> Optional[Repuesto]:
        with DatabaseManager(self.__ruta_bd) as db:
            fila = db.consultar_uno(_SELECT_BASE + "WHERE r.id = ?", (id_repuesto,))
        return Repuesto.desde_tupla(fila) if fila else None

    def listar_stock_bajo(self) -> List[Repuesto]:
        with DatabaseManager(self.__ruta_bd) as db:
            filas = db.consultar_todos(_SELECT_BASE + "WHERE r.stock <= ? ORDER BY r.stock",
                                       (Repuesto.STOCK_MINIMO,))
        return [Repuesto.desde_tupla(f) for f in filas]

    def actualizar(self, repuesto: Repuesto) -> None:
        try:
            with DatabaseManager(self.__ruta_bd) as db:
                db.ejecutar(
                    "UPDATE repuestos SET codigo = ?, nombre = ?, marca = ?, precio = ?, stock = ?, "
                    "categoria_id = ? WHERE id = ?", (*repuesto.a_tupla(), repuesto.id))
        except sqlite3.IntegrityError as e:
            raise traducir_integridad(e, "repuesto") from e

    def eliminar(self, id_repuesto: int) -> None:
        try:
            with DatabaseManager(self.__ruta_bd) as db:
                db.ejecutar("DELETE FROM repuestos WHERE id = ?", (id_repuesto,))
        except sqlite3.IntegrityError as e:
            raise traducir_integridad(e, "repuesto (aparece en facturas)") from e

    def contar(self) -> int:
        with DatabaseManager(self.__ruta_bd) as db:
            return db.consultar_uno("SELECT COUNT(*) FROM repuestos")[0]

    def valor_inventario(self) -> float:
        with DatabaseManager(self.__ruta_bd) as db:
            return db.consultar_uno("SELECT COALESCE(SUM(precio * stock), 0) FROM repuestos")[0]
