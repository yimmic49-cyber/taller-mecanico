"""Patrón DatabaseManager: controla conexión y transacciones con SQLite."""
from __future__ import annotations

import os
import sqlite3
from typing import Any, Iterable, List, Optional

RUTA_BD_POR_DEFECTO = os.path.join(os.path.dirname(os.path.dirname(__file__)), "taller.db")

ESQUEMA_SQL = """
CREATE TABLE IF NOT EXISTS categorias (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre      TEXT NOT NULL UNIQUE,
    descripcion TEXT
);

CREATE TABLE IF NOT EXISTS clientes (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    documento      TEXT NOT NULL UNIQUE,
    nombre         TEXT NOT NULL,
    telefono       TEXT,
    email          TEXT,
    placa_vehiculo TEXT
);

CREATE TABLE IF NOT EXISTS repuestos (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    codigo       TEXT NOT NULL UNIQUE,
    nombre       TEXT NOT NULL,
    marca        TEXT NOT NULL,
    precio       REAL NOT NULL CHECK (precio > 0),
    stock        INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
    categoria_id INTEGER NOT NULL,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS ventas (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    cliente_id INTEGER NOT NULL,
    fecha      TEXT NOT NULL,
    total      REAL NOT NULL CHECK (total >= 0),
    FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS detalle_venta (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    venta_id        INTEGER NOT NULL,
    repuesto_id     INTEGER NOT NULL,
    cantidad        INTEGER NOT NULL CHECK (cantidad > 0),
    precio_unitario REAL NOT NULL CHECK (precio_unitario > 0),
    FOREIGN KEY (venta_id)    REFERENCES ventas(id)    ON DELETE CASCADE,
    FOREIGN KEY (repuesto_id) REFERENCES repuestos(id) ON DELETE RESTRICT
);
"""

DATOS_INICIALES = {
    "categorias": [
        ("Frenos", "Pastillas, discos, bandas y líquido de frenos"),
        ("Motor", "Filtros, bujías, correas y empaques"),
        ("Suspensión", "Amortiguadores, rótulas y terminales"),
        ("Eléctrico", "Baterías, bombillos y alternadores"),
        ("Lubricantes", "Aceites de motor, caja y grasas"),
    ],
    "repuestos": [
        ("FRE-001", "Pastillas de freno delanteras", "Bosch", 85000, 12, 1),
        ("FRE-002", "Disco de freno ventilado", "Brembo", 165000, 4, 1),
        ("MOT-001", "Filtro de aceite", "Mann", 22000, 30, 2),
        ("MOT-002", "Juego de bujías x4", "NGK", 68000, 15, 2),
        ("MOT-003", "Correa de repartición", "Gates", 120000, 3, 2),
        ("SUS-001", "Amortiguador delantero", "Monroe", 210000, 6, 3),
        ("ELE-001", "Batería 12V 45Ah", "MAC", 380000, 5, 4),
        ("LUB-001", "Aceite 20W-50 galón", "Mobil", 98000, 20, 5),
    ],
    "clientes": [
        ("1070123456", "Carlos Pérez", "3104567890", "carlos@correo.com", "GIR123"),
        ("1069987654", "Laura Gómez", "3209876543", "laura@correo.com", "FUS456"),
    ],
}


class DatabaseManager:
    """Gestor de contexto para SQLite.

    Uso:
        with DatabaseManager() as db:
            db.ejecutar("INSERT ...", (a, b))
    Al salir del bloque hace commit() si todo salió bien o rollback() si hubo
    una excepción, y siempre cierra la conexión.
    """

    def __init__(self, ruta: str = RUTA_BD_POR_DEFECTO) -> None:
        self.__ruta: str = ruta
        self.__conexion: Optional[sqlite3.Connection] = None
        self.__cursor: Optional[sqlite3.Cursor] = None

    @property
    def ruta(self) -> str:
        return self.__ruta

    # ----- Métodos mágicos: gestor de contexto -----
    def __enter__(self) -> "DatabaseManager":
        self.__conexion = sqlite3.connect(self.__ruta)
        self.__conexion.execute("PRAGMA foreign_keys = ON;")  # integridad referencial
        self.__cursor = self.__conexion.cursor()
        return self

    def __exit__(self, tipo_exc, valor_exc, traza) -> bool:
        if self.__conexion is not None:
            if tipo_exc is None:
                self.__conexion.commit()
            else:
                self.__conexion.rollback()
            self.__conexion.close()
        self.__conexion = None
        self.__cursor = None
        return False  # no se "traga" la excepción: la capa superior la maneja

    def __repr__(self) -> str:
        return f"DatabaseManager(ruta={self.__ruta!r})"

    # ----- Operaciones (siempre con parámetros ? para evitar inyección SQL) -----
    def _cursor_activo(self) -> sqlite3.Cursor:
        if self.__cursor is None:
            raise RuntimeError("DatabaseManager debe usarse dentro de un bloque 'with'")
        return self.__cursor

    def ejecutar(self, sql: str, parametros: Iterable[Any] = ()) -> sqlite3.Cursor:
        return self._cursor_activo().execute(sql, tuple(parametros))

    def consultar_todos(self, sql: str, parametros: Iterable[Any] = ()) -> List[tuple]:
        return self.ejecutar(sql, parametros).fetchall()

    def consultar_uno(self, sql: str, parametros: Iterable[Any] = ()) -> Optional[tuple]:
        return self.ejecutar(sql, parametros).fetchone()

    @property
    def ultimo_id(self) -> int:
        return self._cursor_activo().lastrowid

    # ----- Inicialización -----
    @classmethod
    def inicializar(cls, ruta: str = RUTA_BD_POR_DEFECTO, con_datos: bool = True) -> None:
        """Crea las tablas y, si la BD está vacía, inserta datos de ejemplo."""
        with cls(ruta) as db:
            db._cursor_activo().executescript(ESQUEMA_SQL)
        with cls(ruta) as db:
            db.ejecutar("PRAGMA foreign_keys = ON;")
            if con_datos and db.consultar_uno("SELECT COUNT(*) FROM categorias")[0] == 0:
                for fila in DATOS_INICIALES["categorias"]:
                    db.ejecutar("INSERT INTO categorias (nombre, descripcion) VALUES (?, ?)", fila)
                for fila in DATOS_INICIALES["repuestos"]:
                    db.ejecutar(
                        "INSERT INTO repuestos (codigo, nombre, marca, precio, stock, categoria_id) "
                        "VALUES (?, ?, ?, ?, ?, ?)", fila)
                for fila in DATOS_INICIALES["clientes"]:
                    db.ejecutar(
                        "INSERT INTO clientes (documento, nombre, telefono, email, placa_vehiculo) "
                        "VALUES (?, ?, ?, ?, ?)", fila)
