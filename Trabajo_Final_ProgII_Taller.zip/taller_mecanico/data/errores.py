"""Traduce errores técnicos de SQLite a mensajes entendibles para el usuario."""
import sqlite3


class ErrorPersistencia(Exception):
    """Error de la capa de datos con un mensaje apto para mostrar en pantalla."""


def traducir_integridad(error: sqlite3.IntegrityError, entidad: str) -> ErrorPersistencia:
    texto = str(error).upper()
    if "UNIQUE" in texto:
        return ErrorPersistencia(f"Ya existe un(a) {entidad} con ese dato único (documento/código/nombre).")
    if "FOREIGN KEY" in texto:
        return ErrorPersistencia(
            f"No se puede completar: el/la {entidad} está relacionado(a) con otros registros.")
    if "CHECK" in texto:
        return ErrorPersistencia(f"Datos inválidos para {entidad} (revise precios, cantidades o stock).")
    return ErrorPersistencia(f"Error de integridad en {entidad}: {error}")
