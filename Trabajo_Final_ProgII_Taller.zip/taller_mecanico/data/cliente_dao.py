"""Patrón DAO para la tabla clientes."""
from __future__ import annotations

import sqlite3
from typing import List, Optional

from data.database_manager import RUTA_BD_POR_DEFECTO, DatabaseManager
from data.errores import traducir_integridad
from domain.cliente import Cliente

_COLUMNAS = "id, documento, nombre, telefono, email, placa_vehiculo"


class ClienteDAO:
    def __init__(self, ruta_bd: str = RUTA_BD_POR_DEFECTO) -> None:
        self.__ruta_bd = ruta_bd

    def crear(self, cliente: Cliente) -> Cliente:
        try:
            with DatabaseManager(self.__ruta_bd) as db:
                db.ejecutar(
                    "INSERT INTO clientes (documento, nombre, telefono, email, placa_vehiculo) "
                    "VALUES (?, ?, ?, ?, ?)", cliente.a_tupla())
                cliente.id = db.ultimo_id
        except sqlite3.IntegrityError as e:
            raise traducir_integridad(e, "cliente") from e
        return cliente

    def listar(self, filtro: str = "") -> List[Cliente]:
        patron = f"%{filtro.strip()}%"
        with DatabaseManager(self.__ruta_bd) as db:
            filas = db.consultar_todos(
                f"SELECT {_COLUMNAS} FROM clientes "
                "WHERE nombre LIKE ? OR documento LIKE ? OR placa_vehiculo LIKE ? "
                "ORDER BY nombre", (patron, patron, patron))
        return [Cliente.desde_tupla(f) for f in filas]

    def obtener_por_id(self, id_cliente: int) -> Optional[Cliente]:
        with DatabaseManager(self.__ruta_bd) as db:
            fila = db.consultar_uno(f"SELECT {_COLUMNAS} FROM clientes WHERE id = ?", (id_cliente,))
        return Cliente.desde_tupla(fila) if fila else None

    def actualizar(self, cliente: Cliente) -> None:
        try:
            with DatabaseManager(self.__ruta_bd) as db:
                db.ejecutar(
                    "UPDATE clientes SET documento = ?, nombre = ?, telefono = ?, email = ?, "
                    "placa_vehiculo = ? WHERE id = ?", (*cliente.a_tupla(), cliente.id))
        except sqlite3.IntegrityError as e:
            raise traducir_integridad(e, "cliente") from e

    def eliminar(self, id_cliente: int) -> None:
        try:
            with DatabaseManager(self.__ruta_bd) as db:
                db.ejecutar("DELETE FROM clientes WHERE id = ?", (id_cliente,))
        except sqlite3.IntegrityError as e:
            raise traducir_integridad(e, "cliente (tiene facturas registradas)") from e

    def contar(self) -> int:
        with DatabaseManager(self.__ruta_bd) as db:
            return db.consultar_uno("SELECT COUNT(*) FROM clientes")[0]
