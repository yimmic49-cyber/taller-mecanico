"""Modelo de dominio: Repuesto / parte que vende el taller."""
from __future__ import annotations

from typing import Optional

from domain.entidad import Entidad


class Repuesto(Entidad):
    STOCK_MINIMO: int = 5  # por debajo de esto se considera "stock bajo"

    def __init__(
        self,
        codigo: str,
        nombre: str,
        marca: str,
        precio: float,
        stock: int,
        categoria_id: int,
        id: Optional[int] = None,
        categoria_nombre: str = "",
    ) -> None:
        super().__init__(id)
        self.codigo = codigo
        self.nombre = nombre
        self.marca = marca
        self.precio = precio
        self.stock = stock
        self.categoria_id = categoria_id
        # Dato de solo lectura que viene del JOIN con categorias
        self._categoria_nombre: str = categoria_nombre

    # ----- Propiedades -----
    @property
    def codigo(self) -> str:
        return self.__codigo

    @codigo.setter
    def codigo(self, valor: str) -> None:
        valor = (valor or "").strip().upper()
        if len(valor) < 3:
            raise ValueError("El código debe tener al menos 3 caracteres")
        self.__codigo = valor

    @property
    def nombre(self) -> str:
        return self.__nombre

    @nombre.setter
    def nombre(self, valor: str) -> None:
        valor = (valor or "").strip()
        if len(valor) < 3:
            raise ValueError("El nombre del repuesto debe tener al menos 3 caracteres")
        self.__nombre = valor

    @property
    def marca(self) -> str:
        return self.__marca

    @marca.setter
    def marca(self, valor: str) -> None:
        valor = (valor or "").strip()
        if not valor:
            raise ValueError("La marca es obligatoria")
        self.__marca = valor

    @property
    def precio(self) -> float:
        return self.__precio

    @precio.setter
    def precio(self, valor: float) -> None:
        try:
            valor = float(valor)
        except (TypeError, ValueError):
            raise ValueError("El precio debe ser un número")
        if valor <= 0:
            raise ValueError("El precio debe ser mayor que cero")
        self.__precio = round(valor, 2)

    @property
    def stock(self) -> int:
        return self.__stock

    @stock.setter
    def stock(self, valor: int) -> None:
        try:
            valor = int(valor)
        except (TypeError, ValueError):
            raise ValueError("El stock debe ser un número entero")
        if valor < 0:
            raise ValueError("El stock no puede ser negativo")
        self.__stock = valor

    @property
    def categoria_id(self) -> int:
        return self.__categoria_id

    @categoria_id.setter
    def categoria_id(self, valor: int) -> None:
        if valor is None or str(valor).strip() == "":
            raise ValueError("Debe seleccionar una categoría")
        self.__categoria_id = int(valor)

    @property
    def categoria_nombre(self) -> str:
        return self._categoria_nombre

    @property
    def stock_bajo(self) -> bool:
        return self.stock <= self.STOCK_MINIMO

    # ----- Fábrica y conversión -----
    @classmethod
    def desde_tupla(cls, fila: tuple) -> "Repuesto":
        """fila = (id, codigo, nombre, marca, precio, stock, categoria_id[, categoria_nombre])"""
        id_, codigo, nombre, marca, precio, stock, categoria_id, *resto = fila
        categoria_nombre = resto[0] if resto else ""
        return cls(codigo, nombre, marca, precio, stock, categoria_id, id_, categoria_nombre or "")

    def a_tupla(self) -> tuple:
        return (self.codigo, self.nombre, self.marca, self.precio, self.stock, self.categoria_id)

    # ----- Métodos mágicos -----
    def __str__(self) -> str:
        return f"[{self.codigo}] {self.nombre} - {self.marca} (${self.precio:,.0f})"

    def __repr__(self) -> str:
        return (f"Repuesto(id={self.id!r}, codigo={self.codigo!r}, nombre={self.nombre!r}, "
                f"precio={self.precio!r}, stock={self.stock!r})")

    def __lt__(self, otro: "Repuesto") -> bool:
        """Permite ordenar repuestos alfabéticamente con sorted()."""
        return self.nombre.lower() < otro.nombre.lower()
