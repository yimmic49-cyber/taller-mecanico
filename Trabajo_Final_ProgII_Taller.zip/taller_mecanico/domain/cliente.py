"""Modelo de dominio: Cliente del taller."""
from __future__ import annotations

import re
from typing import Optional

from domain.entidad import Entidad


class Cliente(Entidad):
    """Cliente que compra repuestos o lleva su vehículo al taller."""

    _PATRON_EMAIL = re.compile(r"^[\w\.\-]+@[\w\-]+\.[\w\.\-]+$")

    def __init__(
        self,
        documento: str,
        nombre: str,
        telefono: str = "",
        email: str = "",
        placa_vehiculo: str = "",
        id: Optional[int] = None,
    ) -> None:
        super().__init__(id)
        self.documento = documento
        self.nombre = nombre
        self.telefono = telefono
        self.email = email
        self.placa_vehiculo = placa_vehiculo

    # ----- Propiedades con validación (encapsulamiento) -----
    @property
    def documento(self) -> str:
        return self.__documento

    @documento.setter
    def documento(self, valor: str) -> None:
        valor = (valor or "").strip()
        if not valor.isdigit() or not 5 <= len(valor) <= 12:
            raise ValueError("El documento debe tener entre 5 y 12 dígitos")
        self.__documento = valor

    @property
    def nombre(self) -> str:
        return self.__nombre

    @nombre.setter
    def nombre(self, valor: str) -> None:
        valor = (valor or "").strip()
        if len(valor) < 3:
            raise ValueError("El nombre debe tener al menos 3 caracteres")
        self.__nombre = valor.title()

    @property
    def telefono(self) -> str:
        return self.__telefono

    @telefono.setter
    def telefono(self, valor: str) -> None:
        valor = (valor or "").strip()
        if valor and (not valor.isdigit() or len(valor) < 7):
            raise ValueError("El teléfono debe tener solo números (mínimo 7)")
        self.__telefono = valor

    @property
    def email(self) -> str:
        return self.__email

    @email.setter
    def email(self, valor: str) -> None:
        valor = (valor or "").strip().lower()
        if valor and not self._PATRON_EMAIL.match(valor):
            raise ValueError("El correo electrónico no es válido")
        self.__email = valor

    @property
    def placa_vehiculo(self) -> str:
        return self.__placa_vehiculo

    @placa_vehiculo.setter
    def placa_vehiculo(self, valor: str) -> None:
        self.__placa_vehiculo = (valor or "").strip().upper()

    # ----- Fábrica y conversión -----
    @classmethod
    def desde_tupla(cls, fila: tuple) -> "Cliente":
        """fila = (id, documento, nombre, telefono, email, placa_vehiculo)"""
        id_, documento, nombre, telefono, email, placa = fila
        return cls(documento, nombre, telefono or "", email or "", placa or "", id_)

    def a_tupla(self) -> tuple:
        return (self.documento, self.nombre, self.telefono, self.email, self.placa_vehiculo)

    # ----- Métodos mágicos -----
    def __str__(self) -> str:
        return f"{self.nombre} (CC {self.documento})"

    def __repr__(self) -> str:
        return f"Cliente(id={self.id!r}, documento={self.documento!r}, nombre={self.nombre!r})"
