"""Clase base abstracta para todas las entidades del dominio."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Optional


class Entidad(ABC):
    """Entidad con identificador (llave primaria en SQLite).

    Implementa __eq__ y __hash__ comunes: dos entidades son iguales si son
    de la misma clase y tienen el mismo id.
    """

    def __init__(self, id: Optional[int] = None) -> None:
        self._id: Optional[int] = id

    @property
    def id(self) -> Optional[int]:
        return self._id

    @id.setter
    def id(self, valor: Optional[int]) -> None:
        if valor is not None and valor <= 0:
            raise ValueError("El id debe ser un entero positivo")
        self._id = valor

    @classmethod
    @abstractmethod
    def desde_tupla(cls, fila: tuple) -> "Entidad":
        """Método de fábrica: construye el objeto desde una fila de SQLite."""

    @abstractmethod
    def a_tupla(self) -> tuple:
        """Devuelve los valores listos para una consulta parametrizada."""

    # ----- Métodos mágicos -----
    def __eq__(self, otro: Any) -> bool:
        if not isinstance(otro, self.__class__):
            return NotImplemented
        if self._id is None or otro._id is None:
            return self is otro
        return self._id == otro._id

    def __hash__(self) -> int:
        return hash((self.__class__.__name__, self._id))
