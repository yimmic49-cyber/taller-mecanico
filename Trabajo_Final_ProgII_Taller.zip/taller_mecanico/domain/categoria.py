"""Modelo de dominio: Categoría de repuestos (frenos, motor, suspensión...)."""
from __future__ import annotations

from typing import Optional

from domain.entidad import Entidad


class Categoria(Entidad):
    def __init__(self, nombre: str, descripcion: str = "", id: Optional[int] = None) -> None:
        super().__init__(id)
        self.nombre = nombre
        self.descripcion = descripcion

    @property
    def nombre(self) -> str:
        return self.__nombre

    @nombre.setter
    def nombre(self, valor: str) -> None:
        valor = (valor or "").strip()
        if len(valor) < 3:
            raise ValueError("El nombre de la categoría debe tener al menos 3 caracteres")
        self.__nombre = valor.capitalize()

    @property
    def descripcion(self) -> str:
        return self.__descripcion

    @descripcion.setter
    def descripcion(self, valor: str) -> None:
        self.__descripcion = (valor or "").strip()

    @classmethod
    def desde_tupla(cls, fila: tuple) -> "Categoria":
        """fila = (id, nombre, descripcion)"""
        id_, nombre, descripcion = fila
        return cls(nombre, descripcion or "", id_)

    def a_tupla(self) -> tuple:
        return (self.nombre, self.descripcion)

    def __str__(self) -> str:
        return self.nombre

    def __repr__(self) -> str:
        return f"Categoria(id={self.id!r}, nombre={self.nombre!r})"
