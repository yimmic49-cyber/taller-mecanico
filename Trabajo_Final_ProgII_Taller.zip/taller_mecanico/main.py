"""Punto de entrada: Sistema de gestión para un taller mecánico con venta de repuestos.

Ejecutar:  python main.py
"""
import flet as ft

from ui.app_view import AppView


def main(page: ft.Page) -> None:
    AppView(page)


if __name__ == "__main__":
    # ft.run en Flet >= 0.80; ft.app en versiones anteriores
    if hasattr(ft, "run"):
        ft.run(main)
    else:
        ft.app(target=main)
