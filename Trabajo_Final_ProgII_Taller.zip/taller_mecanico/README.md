# Taller y Repuestos El Pistón — Sistema de gestión

Proyecto final de **Programación II** (Universidad de Cundinamarca).
Integrantes: Yimmy Alexander Castro Ledesma y Samuel Eduardo Castrellón Prada.
Repositorio: https://github.com/yimmic49-cyber/taller-mecanico
Aplicación de escritorio en **Python + Flet + SQLite** para un taller mecánico que vende partes y repuestos:
registra clientes y sus vehículos, controla el inventario de repuestos por categoría, factura ventas
descontando el stock automáticamente y alerta cuando un repuesto está por agotarse.

## Cómo ejecutar

```bash
pip install -r requirements.txt
python main.py
```

La base de datos `taller.db` se crea sola en la primera ejecución, con categorías, repuestos y clientes de ejemplo.

## Estructura (arquitectura multicapa)

```
taller_mecanico/
├── main.py                      # Punto de entrada
├── README.md
├── informe_final.pdf
├── requirements.txt
├── data/                        # Capa de persistencia
│   ├── database_manager.py      # DatabaseManager (with, commit/rollback, PRAGMA foreign_keys)
│   ├── errores.py               # Traduce errores de SQLite a mensajes para el usuario
│   ├── cliente_dao.py           # ClienteDAO
│   ├── categoria_dao.py         # CategoriaDAO
│   ├── repuesto_repository.py   # RepuestoRepository
│   └── venta_repository.py      # VentaRepository (transacción de 3 tablas)
├── domain/                      # Capa de negocio
│   ├── entidad.py               # Clase base abstracta Entidad
│   ├── cliente.py
│   ├── categoria.py
│   ├── repuesto.py
│   └── venta.py                 # Venta y DetalleVenta
└── ui/                          # Capa de interfaz Flet
    ├── app_view.py              # Ventana principal con NavigationRail
    └── components/
        ├── comunes.py           # Botones, tablas, diálogos y notificaciones
        ├── vista_base.py        # Clase base abstracta de las pantallas
        ├── resumen_view.py      # Indicadores y alertas de stock bajo
        ├── clientes_view.py     # CRUD clientes
        ├── repuestos_view.py    # CRUD repuestos
        ├── categorias_view.py   # CRUD categorías
        └── ventas_view.py       # Facturación, historial, detalle y anulación
```

## Requisitos del curso cubiertos

| Requisito | Dónde |
|---|---|
| 3+ tablas con FOREIGN KEY | `categorias`, `clientes`, `repuestos`, `ventas`, `detalle_venta` (5 tablas) |
| `PRAGMA foreign_keys = ON` | `DatabaseManager.__enter__` |
| Atributos privados, Type Hints, `@classmethod desde_tupla` | Todas las clases de `domain/` |
| Métodos mágicos | `__str__`, `__repr__`, `__eq__`, `__hash__`, `__lt__`, `__len__`, `__iter__`, `__contains__`, `__call__`, `__enter__`/`__exit__` |
| DatabaseManager con `with`, `commit()`/`rollback()` | `data/database_manager.py` |
| DAO / Repository | `ClienteDAO`, `CategoriaDAO`, `RepuestoRepository`, `VentaRepository` |
| Consultas parametrizadas (`?`) | Todas las consultas de `data/` |
| CRUD completo en Flet, validaciones y `page.update()` | `ui/components/*_view.py` |

## Reglas de negocio destacadas

- Una venta se guarda en **una sola transacción**: inserta la factura, sus líneas y descuenta el stock.
  Si algún repuesto no alcanza, se hace `rollback()` y no se guarda nada.
- Anular una factura devuelve las unidades al inventario (`ON DELETE CASCADE` en `detalle_venta`).
- No se puede borrar un cliente con facturas ni una categoría con repuestos (`ON DELETE RESTRICT`).
- Repuestos con stock ≤ 5 se resaltan en rojo y aparecen en el resumen como alerta de pedido.
