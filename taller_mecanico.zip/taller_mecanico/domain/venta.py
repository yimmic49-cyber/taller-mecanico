"""Modelos de dominio: Venta (factura) y DetalleVenta (líneas de la factura)."""
from __future__ import annotations

from datetime import datetime
from typing import Iterator, List, Optional

from domain.entidad import Entidad


class DetalleVenta(Entidad):
    """Una línea de la factura: qué repuesto, cuántas unidades y a qué precio."""

    def __init__(
        self,
        repuesto_id: int,
        cantidad: int,
        precio_unitario: float,
        venta_id: Optional[int] = None,
        id: Optional[int] = None,
        repuesto_nombre: str = "",
    ) -> None:
        super().__init__(id)
        self.repuesto_id = repuesto_id
        self.cantidad = cantidad
        self.precio_unitario = precio_unitario
        self.venta_id = venta_id
        self._repuesto_nombre: str = repuesto_nombre

    @property
    def cantidad(self) -> int:
        return self.__cantidad

    @cantidad.setter
    def cantidad(self, valor: int) -> None:
        try:
            valor = int(valor)
        except (TypeError, ValueError):
            raise ValueError("La cantidad debe ser un número entero")
        if valor <= 0:
            raise ValueError("La cantidad debe ser mayor que cero")
        self.__cantidad = valor

    @property
    def precio_unitario(self) -> float:
        return self.__precio_unitario

    @precio_unitario.setter
    def precio_unitario(self, valor: float) -> None:
        valor = float(valor)
        if valor <= 0:
            raise ValueError("El precio unitario debe ser mayor que cero")
        self.__precio_unitario = valor

    @property
    def repuesto_nombre(self) -> str:
        return self._repuesto_nombre

    @property
    def subtotal(self) -> float:
        return self.cantidad * self.precio_unitario

    @classmethod
    def desde_tupla(cls, fila: tuple) -> "DetalleVenta":
        """fila = (id, venta_id, repuesto_id, cantidad, precio_unitario[, repuesto_nombre])"""
        id_, venta_id, repuesto_id, cantidad, precio, *resto = fila
        return cls(repuesto_id, cantidad, precio, venta_id, id_, resto[0] if resto else "")

    def a_tupla(self) -> tuple:
        return (self.venta_id, self.repuesto_id, self.cantidad, self.precio_unitario)

    def __str__(self) -> str:
        return f"{self.cantidad} x {self.repuesto_nombre or self.repuesto_id} = ${self.subtotal:,.0f}"

    def __repr__(self) -> str:
        return (f"DetalleVenta(repuesto_id={self.repuesto_id!r}, cantidad={self.cantidad!r}, "
                f"precio_unitario={self.precio_unitario!r})")


class Venta(Entidad):
    """Factura de venta de repuestos a un cliente. Agrega varios DetalleVenta."""

    FORMATO_FECHA = "%Y-%m-%d %H:%M"

    def __init__(
        self,
        cliente_id: int,
        fecha: Optional[str] = None,
        id: Optional[int] = None,
        cliente_nombre: str = "",
        total_guardado: Optional[float] = None,
        devuelto: float = 0.0,
    ) -> None:
        super().__init__(id)
        if cliente_id is None or str(cliente_id).strip() == "":
            raise ValueError("Debe seleccionar un cliente")
        self.__cliente_id: int = int(cliente_id)
        self.__fecha: str = fecha or datetime.now().strftime(self.FORMATO_FECHA)
        self.__detalles: List[DetalleVenta] = []
        self._cliente_nombre: str = cliente_nombre
        self._total_guardado: Optional[float] = total_guardado
        self._devuelto: float = float(devuelto or 0)

    @property
    def devuelto(self) -> float:
        """Valor de los repuestos que el cliente ya devolvió de esta factura."""
        return self._devuelto

    @property
    def neto(self) -> float:
        """Total de la factura menos las devoluciones."""
        return self.total - self._devuelto

    @property
    def cliente_id(self) -> int:
        return self.__cliente_id

    @property
    def fecha(self) -> str:
        return self.__fecha

    @property
    def cliente_nombre(self) -> str:
        return self._cliente_nombre

    @property
    def detalles(self) -> List[DetalleVenta]:
        return list(self.__detalles)  # copia: protege la lista interna

    def agregar_detalle(self, detalle: DetalleVenta) -> None:
        """Agrega una línea; si el repuesto ya está, suma la cantidad."""
        for existente in self.__detalles:
            if existente.repuesto_id == detalle.repuesto_id:
                existente.cantidad = existente.cantidad + detalle.cantidad
                return
        self.__detalles.append(detalle)

    def quitar_detalle(self, repuesto_id: int) -> None:
        self.__detalles = [d for d in self.__detalles if d.repuesto_id != repuesto_id]

    @property
    def total(self) -> float:
        if self.__detalles:
            return sum(d.subtotal for d in self.__detalles)
        return self._total_guardado or 0.0

    @classmethod
    def desde_tupla(cls, fila: tuple) -> "Venta":
        """fila = (id, cliente_id, fecha, total[, cliente_nombre[, devuelto]])"""
        id_, cliente_id, fecha, total, *resto = fila
        cliente_nombre = resto[0] if len(resto) > 0 else ""
        devuelto = resto[1] if len(resto) > 1 else 0.0
        return cls(cliente_id, fecha, id_, cliente_nombre, total, devuelto)

    def a_tupla(self) -> tuple:
        return (self.cliente_id, self.fecha, self.total)

    # ----- Métodos mágicos -----
    def __len__(self) -> int:
        """Cantidad de líneas (repuestos distintos) en la factura."""
        return len(self.__detalles)

    def __iter__(self) -> Iterator[DetalleVenta]:
        return iter(self.__detalles)

    def __contains__(self, repuesto_id: int) -> bool:
        return any(d.repuesto_id == repuesto_id for d in self.__detalles)

    def __call__(self) -> float:
        """venta() devuelve el total a pagar."""
        return self.total

    def __str__(self) -> str:
        return f"Factura #{self.id or 'nueva'} - {self.fecha} - ${self.total:,.0f}"

    def __repr__(self) -> str:
        return f"Venta(id={self.id!r}, cliente_id={self.cliente_id!r}, total={self.total!r})"
