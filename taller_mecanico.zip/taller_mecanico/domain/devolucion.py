"""Modelo de dominio: Devolución de repuestos de una factura."""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from domain.entidad import Entidad


class Devolucion(Entidad):


    FORMATO_FECHA = "%Y-%m-%d %H:%M"

    def __init__(
        self,
        venta_id: int,
        repuesto_id: int,
        cantidad: int,
        motivo: str,
        valor: float = 0.0,
        fecha: Optional[str] = None,
        id: Optional[int] = None,
        repuesto_nombre: str = "",
    ) -> None:
        super().__init__(id)
        if not venta_id:
            raise ValueError("La devolución debe pertenecer a una factura")
        if repuesto_id is None or str(repuesto_id).strip() == "":
            raise ValueError("Seleccione el repuesto que se devuelve")
        self.__venta_id: int = int(venta_id)
        self.__repuesto_id: int = int(repuesto_id)
        self.cantidad = cantidad
        self.motivo = motivo
        self.valor = valor
        self.__fecha: str = fecha or datetime.now().strftime(self.FORMATO_FECHA)
        self._repuesto_nombre: str = repuesto_nombre

    @property
    def venta_id(self) -> int:
        return self.__venta_id

    @property
    def repuesto_id(self) -> int:
        return self.__repuesto_id

    @property
    def fecha(self) -> str:
        return self.__fecha

    @property
    def repuesto_nombre(self) -> str:
        return self._repuesto_nombre

    @property
    def cantidad(self) -> int:
        return self.__cantidad

    @cantidad.setter
    def cantidad(self, valor: int) -> None:
        try:
            valor = int(valor)
        except (TypeError, ValueError):
            raise ValueError("La cantidad a devolver debe ser un número entero")
        if valor <= 0:
            raise ValueError("La cantidad a devolver debe ser mayor que cero")
        self.__cantidad = valor

    @property
    def motivo(self) -> str:
        return self.__motivo

    @motivo.setter
    def motivo(self, valor: str) -> None:
        valor = (valor or "").strip()
        if len(valor) < 3:
            raise ValueError("Escriba el motivo de la devolución (mínimo 3 caracteres)")
        self.__motivo = valor

    @property
    def valor(self) -> float:
        return self.__valor

    @valor.setter
    def valor(self, valor: float) -> None:
        valor = float(valor)
        if valor < 0:
            raise ValueError("El valor devuelto no puede ser negativo")
        self.__valor = valor

    @classmethod
    def desde_tupla(cls, fila: tuple) -> "Devolucion":
        """fila = (id, venta_id, repuesto_id, cantidad, valor, motivo, fecha[, repuesto_nombre])"""
        id_, venta_id, repuesto_id, cantidad, valor, motivo, fecha, *resto = fila
        return cls(venta_id, repuesto_id, cantidad, motivo, valor, fecha, id_, resto[0] if resto else "")

    def a_tupla(self) -> tuple:
        return (self.venta_id, self.repuesto_id, self.cantidad, self.valor, self.motivo, self.fecha)

    def __str__(self) -> str:
        return f"Devolución de {self.cantidad} x {self.repuesto_nombre or self.repuesto_id} (${self.valor:,.0f})"

    def __repr__(self) -> str:
        return (f"Devolucion(venta_id={self.venta_id!r}, repuesto_id={self.repuesto_id!r}, "
                f"cantidad={self.cantidad!r})")
