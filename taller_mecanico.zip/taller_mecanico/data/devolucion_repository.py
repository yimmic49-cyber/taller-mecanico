"""Patrón Repository para devoluciones de repuestos.

Una devolución, en UNA sola transacción:
  1. Verifica que la cantidad no supere lo vendido menos lo ya devuelto.
  2. Calcula su valor con el precio al que se vendió (no el precio actual).
  3. Inserta la devolución y suma las unidades de nuevo al inventario.
"""
from __future__ import annotations

from typing import List, NamedTuple

from data.database_manager import RUTA_BD_POR_DEFECTO, DatabaseManager
from data.errores import ErrorPersistencia
from domain.devolucion import Devolucion


class LineaDevolvible(NamedTuple):
    repuesto_id: int
    nombre: str
    vendido: int
    devuelto: int
    precio_unitario: float

    @property
    def disponible(self) -> int:
        return self.vendido - self.devuelto


_SQL_LINEAS = (
    "SELECT d.repuesto_id, r.nombre, d.cantidad, "
    "COALESCE((SELECT SUM(x.cantidad) FROM devoluciones x "
    "          WHERE x.venta_id = d.venta_id AND x.repuesto_id = d.repuesto_id), 0), "
    "d.precio_unitario "
    "FROM detalle_venta d INNER JOIN repuestos r ON r.id = d.repuesto_id "
    "WHERE d.venta_id = ? "
)


class DevolucionRepository:
    def __init__(self, ruta_bd: str = RUTA_BD_POR_DEFECTO) -> None:
        self.__ruta_bd = ruta_bd

    def lineas_devolvibles(self, id_venta: int) -> List[LineaDevolvible]:
        """Repuestos de la factura con cuántas unidades se pueden devolver aún."""
        with DatabaseManager(self.__ruta_bd) as db:
            filas = db.consultar_todos(_SQL_LINEAS, (id_venta,))
        return [LineaDevolvible(*f) for f in filas]

    def registrar(self, devolucion: Devolucion) -> Devolucion:
        with DatabaseManager(self.__ruta_bd) as db:
            fila = db.consultar_uno(_SQL_LINEAS + "AND d.repuesto_id = ?",
                                    (devolucion.venta_id, devolucion.repuesto_id))
            if fila is None:
                raise ErrorPersistencia("Ese repuesto no está en la factura")
            linea = LineaDevolvible(*fila)
            if devolucion.cantidad > linea.disponible:
                raise ErrorPersistencia(
                    f"Solo se pueden devolver {linea.disponible} unidad(es) de '{linea.nombre}' "
                    f"(vendidas: {linea.vendido}, ya devueltas: {linea.devuelto})")
            devolucion.valor = devolucion.cantidad * linea.precio_unitario
            db.ejecutar(
                "INSERT INTO devoluciones (venta_id, repuesto_id, cantidad, valor, motivo, fecha) "
                "VALUES (?, ?, ?, ?, ?, ?)", devolucion.a_tupla())
            devolucion.id = db.ultimo_id
            db.ejecutar("UPDATE repuestos SET stock = stock + ? WHERE id = ?",
                        (devolucion.cantidad, devolucion.repuesto_id))
        return devolucion

    def listar_por_venta(self, id_venta: int) -> List[Devolucion]:
        with DatabaseManager(self.__ruta_bd) as db:
            filas = db.consultar_todos(
                "SELECT x.id, x.venta_id, x.repuesto_id, x.cantidad, x.valor, x.motivo, x.fecha, r.nombre "
                "FROM devoluciones x INNER JOIN repuestos r ON r.id = x.repuesto_id "
                "WHERE x.venta_id = ? ORDER BY x.id", (id_venta,))
        return [Devolucion.desde_tupla(f) for f in filas]

    def total_devuelto(self) -> float:
        with DatabaseManager(self.__ruta_bd) as db:
            return db.consultar_uno("SELECT COALESCE(SUM(valor), 0) FROM devoluciones")[0]

    def contar(self) -> int:
        with DatabaseManager(self.__ruta_bd) as db:
            return db.consultar_uno("SELECT COUNT(*) FROM devoluciones")[0]
