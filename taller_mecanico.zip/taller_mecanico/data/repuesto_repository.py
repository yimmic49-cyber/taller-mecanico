"""Patrón Repository para los repuestos (inventario del taller).

Eliminación inteligente: un repuesto que aparece en facturas o devoluciones se
ARCHIVA (activo = 0) para conservar el historial; si nunca se vendió, se borra.
"""
from __future__ import annotations

import sqlite3
from typing import List, Optional

from data.cliente_dao import ARCHIVADO, ELIMINADO
from data.database_manager import RUTA_BD_POR_DEFECTO, DatabaseManager
from data.errores import traducir_integridad
from domain.repuesto import Repuesto

_SELECT_BASE = (
    "SELECT r.id, r.codigo, r.nombre, r.marca, r.precio, r.stock, r.categoria_id, c.nombre "
    "FROM repuestos r INNER JOIN categorias c ON c.id = r.categoria_id "
)


class RepuestoRepository:
    def __init__(self, ruta_bd: str = RUTA_BD_POR_DEFECTO) -> None:
        self.__ruta_bd = ruta_bd

    def agregar(self, repuesto: Repuesto) -> Repuesto:
        """Inserta el repuesto. Si existía archivado con el mismo código, lo reactiva."""
        try:
            with DatabaseManager(self.__ruta_bd) as db:
                previo = db.consultar_uno("SELECT id, activo FROM repuestos WHERE codigo = ?",
                                          (repuesto.codigo,))
                if previo and previo[1] == 0:
                    db.ejecutar(
                        "UPDATE repuestos SET nombre = ?, marca = ?, precio = ?, stock = ?, "
                        "categoria_id = ?, activo = 1 WHERE id = ?", (*repuesto.a_tupla()[1:], previo[0]))
                    repuesto.id = previo[0]
                else:
                    db.ejecutar(
                        "INSERT INTO repuestos (codigo, nombre, marca, precio, stock, categoria_id) "
                        "VALUES (?, ?, ?, ?, ?, ?)", repuesto.a_tupla())
                    repuesto.id = db.ultimo_id
        except sqlite3.IntegrityError as e:
            raise traducir_integridad(e, "repuesto") from e
        return repuesto

    def listar(self, filtro: str = "", categoria_id: Optional[int] = None) -> List[Repuesto]:
        """Solo repuestos activos."""
        patron = f"%{filtro.strip()}%"
        sql = _SELECT_BASE + "WHERE r.activo = 1 AND (r.nombre LIKE ? OR r.codigo LIKE ? OR r.marca LIKE ?) "
        parametros: list = [patron, patron, patron]
        if categoria_id:
            sql += "AND r.categoria_id = ? "
            parametros.append(categoria_id)
        sql += "ORDER BY r.nombre"
        with DatabaseManager(self.__ruta_bd) as db:
            filas = db.consultar_todos(sql, parametros)
        return [Repuesto.desde_tupla(f) for f in filas]

    def obtener_por_id(self, id_repuesto: int) -> Optional[Repuesto]:
        with DatabaseManager(self.__ruta_bd) as db:
            fila = db.consultar_uno(_SELECT_BASE + "WHERE r.id = ?", (id_repuesto,))
        return Repuesto.desde_tupla(fila) if fila else None

    def listar_stock_bajo(self) -> List[Repuesto]:
        with DatabaseManager(self.__ruta_bd) as db:
            filas = db.consultar_todos(
                _SELECT_BASE + "WHERE r.activo = 1 AND r.stock <= ? ORDER BY r.stock",
                (Repuesto.STOCK_MINIMO,))
        return [Repuesto.desde_tupla(f) for f in filas]

    def actualizar(self, repuesto: Repuesto) -> None:
        try:
            with DatabaseManager(self.__ruta_bd) as db:
                db.ejecutar(
                    "UPDATE repuestos SET codigo = ?, nombre = ?, marca = ?, precio = ?, stock = ?, "
                    "categoria_id = ? WHERE id = ?", (*repuesto.a_tupla(), repuesto.id))
        except sqlite3.IntegrityError as e:
            raise traducir_integridad(e, "repuesto") from e

    def eliminar(self, id_repuesto: int) -> str:
        """Devuelve 'eliminado' o 'archivado' según si el repuesto tiene historial."""
        with DatabaseManager(self.__ruta_bd) as db:
            usos = db.consultar_uno(
                "SELECT (SELECT COUNT(*) FROM detalle_venta WHERE repuesto_id = ?) + "
                "(SELECT COUNT(*) FROM devoluciones WHERE repuesto_id = ?)",
                (id_repuesto, id_repuesto))[0]
            if usos > 0:
                db.ejecutar("UPDATE repuestos SET activo = 0 WHERE id = ?", (id_repuesto,))
                return ARCHIVADO
            db.ejecutar("DELETE FROM repuestos WHERE id = ?", (id_repuesto,))
            return ELIMINADO

    def contar(self) -> int:
        with DatabaseManager(self.__ruta_bd) as db:
            return db.consultar_uno("SELECT COUNT(*) FROM repuestos WHERE activo = 1")[0]

    def valor_inventario(self) -> float:
        with DatabaseManager(self.__ruta_bd) as db:
            return db.consultar_uno(
                "SELECT COALESCE(SUM(precio * stock), 0) FROM repuestos WHERE activo = 1")[0]
