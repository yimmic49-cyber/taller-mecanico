"""Patrón DAO para la tabla categorias."""
from __future__ import annotations

import sqlite3
from typing import List

from data.database_manager import RUTA_BD_POR_DEFECTO, DatabaseManager
from data.errores import ErrorPersistencia, traducir_integridad
from domain.categoria import Categoria


class CategoriaDAO:
    def __init__(self, ruta_bd: str = RUTA_BD_POR_DEFECTO) -> None:
        self.__ruta_bd = ruta_bd

    def crear(self, categoria: Categoria) -> Categoria:
        try:
            with DatabaseManager(self.__ruta_bd) as db:
                db.ejecutar("INSERT INTO categorias (nombre, descripcion) VALUES (?, ?)",
                            categoria.a_tupla())
                categoria.id = db.ultimo_id
        except sqlite3.IntegrityError as e:
            raise traducir_integridad(e, "categoría") from e
        return categoria

    def listar(self) -> List[Categoria]:
        with DatabaseManager(self.__ruta_bd) as db:
            filas = db.consultar_todos("SELECT id, nombre, descripcion FROM categorias ORDER BY nombre")
        return [Categoria.desde_tupla(f) for f in filas]

    def actualizar(self, categoria: Categoria) -> None:
        try:
            with DatabaseManager(self.__ruta_bd) as db:
                db.ejecutar("UPDATE categorias SET nombre = ?, descripcion = ? WHERE id = ?",
                            (*categoria.a_tupla(), categoria.id))
        except sqlite3.IntegrityError as e:
            raise traducir_integridad(e, "categoría") from e

    def eliminar(self, id_categoria: int) -> None:
        """Solo se puede borrar una categoría sin repuestos (activos o archivados)."""
        with DatabaseManager(self.__ruta_bd) as db:
            activos, archivados = db.consultar_uno(
                "SELECT COALESCE(SUM(activo = 1), 0), COALESCE(SUM(activo = 0), 0) "
                "FROM repuestos WHERE categoria_id = ?", (id_categoria,))
            if activos:
                raise ErrorPersistencia(
                    f"La categoría tiene {activos} repuesto(s). Muévalos a otra categoría o elimínelos primero.")
            if archivados:
                raise ErrorPersistencia(
                    "La categoría tiene repuestos archivados con historial de ventas; "
                    "no se puede borrar. Puede renombrarla.")
            db.ejecutar("DELETE FROM categorias WHERE id = ?", (id_categoria,))
