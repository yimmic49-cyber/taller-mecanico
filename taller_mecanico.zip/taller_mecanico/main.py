
import flet as ft

from ui.app_view import AppView


def main(page: ft.Page) -> None:
    AppView(page)


if __name__ == "__main__":

    if hasattr(ft, "run"):
        ft.run(main)
    else:
        ft.app(target=main)
