"""Pantalla de facturación: venta de repuestos, historial y devoluciones.

Una factura registrada NO se puede eliminar: solo se corrige con devoluciones.
"""
from __future__ import annotations

from typing import Dict, Optional

import flet as ft

from data.cliente_dao import ClienteDAO
from data.devolucion_repository import DevolucionRepository
from data.errores import ErrorPersistencia
from data.repuesto_repository import RepuestoRepository
from data.venta_repository import VentaRepository
from domain.devolucion import Devolucion
from domain.repuesto import Repuesto
from domain.venta import DetalleVenta, Venta
from ui.components.comunes import (Colors, Icons, abrir_dialogo, boton, celda, cerrar_dialogo,
                                   crear_tabla, opcion, pesos, tarjeta, titulo_seccion)
from ui.components.vista_base import VistaBase


class VentasView(VistaBase):
    def __init__(self, page: ft.Page, venta_repo: VentaRepository, cliente_dao: ClienteDAO,
                 repuesto_repo: RepuestoRepository, devolucion_repo: DevolucionRepository) -> None:
        self.__venta_repo = venta_repo
        self.__cliente_dao = cliente_dao
        self.__repuesto_repo = repuesto_repo
        self.__devolucion_repo = devolucion_repo
        self.__repuestos: Dict[str, Repuesto] = {}
        self.__carrito: Optional[Venta] = None
        super().__init__(page)

    def _construir(self) -> ft.Control:
        self.dd_cliente = ft.Dropdown(label="Cliente *", width=300, options=[])
        self.dd_repuesto = ft.Dropdown(label="Repuesto *", width=380, options=[])
        self.txt_cantidad = ft.TextField(label="Cantidad", value="1", width=100,
                                         keyboard_type=ft.KeyboardType.NUMBER)
        self.tabla_carrito = crear_tabla(["Repuesto", "Cant.", "Precio unit.", "Subtotal", ""],
                                         numericas=[1, 2, 3])
        self.lbl_total = ft.Text("Total: $0", size=20, weight=ft.FontWeight.BOLD, color=Colors.GREEN_800)
        self.tabla_historial = crear_tabla(["N°", "Fecha", "Cliente", "Total", "Devuelto", "Neto", "Acciones"],
                                           numericas=[3, 4, 5])

        nueva_factura = ft.Column([
            ft.Text("Nueva factura", weight=ft.FontWeight.BOLD),
            ft.Row([self.dd_cliente], wrap=True),
            ft.Row([self.dd_repuesto, self.txt_cantidad,
                    boton("Agregar", Icons.ADD_SHOPPING_CART, self._agregar_al_carrito)], wrap=True),
            ft.Row([self.tabla_carrito], scroll=ft.ScrollMode.AUTO),
            ft.Row([
                self.lbl_total,
                boton("Registrar factura", Icons.POINT_OF_SALE, self._registrar),
                boton("Cancelar", Icons.CLEAR, lambda e: self._nuevo_carrito(), secundario=True),
            ], wrap=True, spacing=20),
        ], scroll=ft.ScrollMode.AUTO)
        historial = ft.Column([
            ft.Text("Historial de facturas  (ver detalle · devolución)", weight=ft.FontWeight.BOLD),
            ft.Text("Las facturas registradas no se pueden eliminar; para corregir una venta use Devolución.",
                    italic=True, color=Colors.BLUE_GREY_600),
            ft.Column([ft.Row([self.tabla_historial], scroll=ft.ScrollMode.AUTO)],
                      scroll=ft.ScrollMode.AUTO, expand=True),
        ], expand=True)
        return ft.Column([
            titulo_seccion("Ventas / Facturación", Icons.POINT_OF_SALE),
            ft.Row([tarjeta(nueva_factura, expand=True), tarjeta(historial, expand=True)],
                   expand=True, vertical_alignment=ft.CrossAxisAlignment.START),
        ], expand=True)

    # ----- Carga de datos -----
    def refrescar(self) -> None:
        clientes = self.__cliente_dao.listar()
        ids_clientes = {str(c.id) for c in clientes}
        self.dd_cliente.options = [opcion(str(c.id), str(c)) for c in clientes]
        if self.dd_cliente.value not in ids_clientes:  # el cliente pudo ser archivado
            self.dd_cliente.value = None
        self.__repuestos = {str(r.id): r for r in self.__repuesto_repo.listar() if r.stock > 0}
        self.dd_repuesto.options = [
            opcion(k, f"{r.codigo} - {r.nombre} ({r.stock} disp.) {pesos(r.precio)}")
            for k, r in self.__repuestos.items()
        ]
        if self.dd_repuesto.value not in self.__repuestos:
            self.dd_repuesto.value = None
        self._pintar_carrito()
        self._pintar_historial()
        self._actualizar()

    def _pintar_historial(self) -> None:
        self.tabla_historial.rows.clear()
        for v in self.__venta_repo.listar():
            self.tabla_historial.rows.append(ft.DataRow(cells=[
                celda(v.id), celda(v.fecha), celda(v.cliente_nombre), celda(pesos(v.total)),
                celda(pesos(v.devuelto) if v.devuelto else "-"), celda(pesos(v.neto)),
                ft.DataCell(content=ft.Row([
                    ft.IconButton(icon=Icons.VISIBILITY, icon_color=Colors.BLUE_600, tooltip="Ver detalle",
                                  on_click=lambda e, ven=v: self._ver_detalle(ven.id)),
                    ft.IconButton(icon=Icons.UNDO, icon_color=Colors.ORANGE_700,
                                  tooltip="Registrar devolución",
                                  on_click=lambda e, ven=v: self._devolver(ven.id)),
                ], spacing=0)),
            ]))

    # ----- Carrito -----
    def _lineas(self):
        return list(self.__carrito) if self.__carrito is not None else []

    def _pintar_carrito(self) -> None:
        self.tabla_carrito.rows.clear()
        for d in self._lineas():
            self.tabla_carrito.rows.append(ft.DataRow(cells=[
                celda(d.repuesto_nombre), celda(d.cantidad), celda(pesos(d.precio_unitario)),
                celda(pesos(d.subtotal)),
                ft.DataCell(content=ft.IconButton(
                    icon=Icons.REMOVE_CIRCLE, icon_color=Colors.RED_600, tooltip="Quitar",
                    on_click=lambda e, rid=d.repuesto_id: self._quitar(rid))),
            ]))
        total = self.__carrito() if self.__carrito is not None else 0
        self.lbl_total.value = f"Total: {pesos(total)}"

    def _rehacer_carrito(self, cliente_id) -> None:
        """Crea el carrito para el cliente elegido conservando las líneas ya agregadas."""
        lineas = self._lineas()
        self.__carrito = Venta(cliente_id)
        for d in lineas:
            self.__carrito.agregar_detalle(d)

    def _agregar_al_carrito(self, e) -> None:
        try:
            if not self.dd_cliente.value:
                raise ValueError("Primero seleccione el cliente")
            repuesto = self.__repuestos.get(self.dd_repuesto.value or "")
            if repuesto is None:
                raise ValueError("Seleccione un repuesto")
            if self.__carrito is None or self.__carrito.cliente_id != int(self.dd_cliente.value):
                self._rehacer_carrito(self.dd_cliente.value)
            detalle = DetalleVenta(repuesto.id, self.txt_cantidad.value, repuesto.precio,
                                   repuesto_nombre=repuesto.nombre)
            ya_en_carrito = sum(d.cantidad for d in self.__carrito if d.repuesto_id == repuesto.id)
            if ya_en_carrito + detalle.cantidad > repuesto.stock:
                raise ValueError(f"Solo hay {repuesto.stock} unidades de {repuesto.nombre}")
            self.__carrito.agregar_detalle(detalle)
            self.txt_cantidad.value = "1"
            self._pintar_carrito()
            self._actualizar()
        except ValueError as ex:
            self._error(str(ex))

    def _quitar(self, repuesto_id: int) -> None:
        if self.__carrito is not None:
            self.__carrito.quitar_detalle(repuesto_id)
        self._pintar_carrito()
        self._actualizar()

    def _nuevo_carrito(self) -> None:
        self.__carrito = None
        self.dd_repuesto.value = None
        self.txt_cantidad.value = "1"
        self.refrescar()

    # ----- Registrar -----
    def _registrar(self, e) -> None:
        try:
            if self.__carrito is None or len(self.__carrito) == 0:
                raise ValueError("Agregue al menos un repuesto a la factura")
            if not self.dd_cliente.value:
                raise ValueError("Seleccione el cliente")
            if str(self.__carrito.cliente_id) != str(self.dd_cliente.value):
                self._rehacer_carrito(self.dd_cliente.value)
            venta = self.__venta_repo.registrar(self.__carrito)
            self._ok(f"Factura #{venta.id} registrada por {pesos(venta.total)}")
            self.dd_cliente.value = None
            self._nuevo_carrito()
        except (ValueError, ErrorPersistencia) as ex:
            self._error(str(ex))

    # ----- Ver detalle -----
    def _ver_detalle(self, id_venta: int) -> None:
        venta = self.__venta_repo.obtener_por_id(id_venta)
        if venta is None:
            self._error("La factura ya no existe")
            self.refrescar()
            return
        tabla = crear_tabla(["Repuesto", "Cant.", "Precio", "Subtotal"], numericas=[1, 2, 3])
        for d in venta:
            tabla.rows.append(ft.DataRow(cells=[
                celda(d.repuesto_nombre), celda(d.cantidad), celda(pesos(d.precio_unitario)),
                celda(pesos(d.subtotal))]))
        contenido = [
            ft.Text(f"Cliente: {venta.cliente_nombre}"),
            ft.Text(f"Fecha: {venta.fecha}"),
            tabla,
            ft.Text(f"TOTAL: {pesos(venta.total)}  ({len(venta)} repuestos distintos)",
                    weight=ft.FontWeight.BOLD),
        ]
        devoluciones = self.__devolucion_repo.listar_por_venta(id_venta)
        if devoluciones:
            tabla_dev = crear_tabla(["Fecha", "Repuesto", "Cant.", "Valor", "Motivo"], numericas=[2, 3])
            for x in devoluciones:
                tabla_dev.rows.append(ft.DataRow(cells=[
                    celda(x.fecha), celda(x.repuesto_nombre), celda(x.cantidad),
                    celda(pesos(x.valor)), celda(x.motivo)]))
            contenido += [ft.Text("Devoluciones", weight=ft.FontWeight.BOLD, color=Colors.ORANGE_800),
                          tabla_dev,
                          ft.Text(f"NETO: {pesos(venta.neto)}", weight=ft.FontWeight.BOLD,
                                  color=Colors.GREEN_800)]
        dialogo: Optional[ft.AlertDialog] = None
        dialogo = ft.AlertDialog(
            title=ft.Text(f"Factura #{venta.id}"),
            content=ft.Column(contenido, tight=True, scroll=ft.ScrollMode.AUTO),
            actions=[ft.TextButton(content=ft.Text("Cerrar"),
                                   on_click=lambda e: cerrar_dialogo(self._page, dialogo))],
        )
        abrir_dialogo(self._page, dialogo)

    # ----- Devolución -----
    def _devolver(self, id_venta: int) -> None:
        lineas = [l for l in self.__devolucion_repo.lineas_devolvibles(id_venta) if l.disponible > 0]
        if not lineas:
            self._error(f"La factura #{id_venta} ya no tiene repuestos por devolver")
            return
        dd_linea = ft.Dropdown(
            label="Repuesto a devolver *", width=420,
            options=[opcion(str(l.repuesto_id),
                            f"{l.nombre} (puede devolver {l.disponible} de {l.vendido})")
                     for l in lineas])
        if len(lineas) == 1:
            dd_linea.value = str(lineas[0].repuesto_id)
        txt_cant = ft.TextField(label="Cantidad *", value="1", width=120,
                                keyboard_type=ft.KeyboardType.NUMBER)
        txt_motivo = ft.TextField(label="Motivo *", width=420,
                                  hint_text="Ej: pieza defectuosa, no era la referencia")
        lbl_error = ft.Text("", color=Colors.RED_700)  # errores dentro del diálogo
        dialogo: Optional[ft.AlertDialog] = None

        def registrar(e) -> None:
            try:
                devolucion = Devolucion(id_venta, dd_linea.value, txt_cant.value, txt_motivo.value)
                self.__devolucion_repo.registrar(devolucion)
                cerrar_dialogo(self._page, dialogo)
                self._ok(f"Devolución registrada: {pesos(devolucion.valor)} y "
                         f"{devolucion.cantidad} unidad(es) volvieron al inventario")
                self.refrescar()
            except (ValueError, ErrorPersistencia) as ex:
                lbl_error.value = str(ex)
                self._actualizar()

        dialogo = ft.AlertDialog(
            modal=True,
            title=ft.Text(f"Devolución - Factura #{id_venta}"),
            content=ft.Column([
                ft.Text("Las unidades devueltas vuelven al inventario y su valor se descuenta "
                        "del total vendido."),
                dd_linea, txt_cant, txt_motivo, lbl_error,
            ], tight=True),
            actions=[
                ft.TextButton(content=ft.Text("Cancelar"),
                              on_click=lambda e: cerrar_dialogo(self._page, dialogo)),
                ft.FilledButton(content=ft.Text("Registrar devolución"), on_click=registrar),
            ],
        )
        abrir_dialogo(self._page, dialogo)
