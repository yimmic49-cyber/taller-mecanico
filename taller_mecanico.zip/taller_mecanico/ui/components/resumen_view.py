"""Pantalla de inicio: indicadores del taller y alertas de stock bajo.

Usa los mismos controles que las demás pantallas (tarjeta + DataTable),
que son compatibles con todas las versiones de Flet.
"""
from __future__ import annotations

import flet as ft

from data.cliente_dao import ClienteDAO
from data.devolucion_repository import DevolucionRepository
from data.repuesto_repository import RepuestoRepository
from data.venta_repository import VentaRepository
from ui.components.comunes import Icons, celda, crear_tabla, pesos, tarjeta, titulo_seccion
from ui.components.vista_base import VistaBase


class ResumenView(VistaBase):
    def __init__(self, page: ft.Page, cliente_dao: ClienteDAO, repuesto_repo: RepuestoRepository,
                 venta_repo: VentaRepository, devolucion_repo: DevolucionRepository) -> None:
        self.__cliente_dao = cliente_dao
        self.__repuesto_repo = repuesto_repo
        self.__venta_repo = venta_repo
        self.__devolucion_repo = devolucion_repo
        super().__init__(page)

    def _construir(self) -> ft.Control:
        self.tabla_indicadores = crear_tabla(["Indicador", "Valor"])
        self.tabla_alertas = crear_tabla(["Código", "Repuesto", "Marca", "Stock"], numericas=[3])
        return ft.Column([
            titulo_seccion("Resumen del taller", Icons.DASHBOARD),
            tarjeta(ft.Column([
                ft.Text("Indicadores del negocio", weight=ft.FontWeight.BOLD),
                ft.Row([self.tabla_indicadores], scroll=ft.ScrollMode.AUTO),
            ])),
            tarjeta(ft.Column([
                ft.Text("Repuestos con stock bajo (5 unidades o menos): hay que pedir al proveedor",
                        weight=ft.FontWeight.BOLD),
                ft.Column([ft.Row([self.tabla_alertas], scroll=ft.ScrollMode.AUTO)],
                          scroll=ft.ScrollMode.AUTO, expand=True),
            ], expand=True), expand=True),
        ], expand=True)

    def refrescar(self) -> None:
        indicadores = [
            ("Clientes registrados", str(self.__cliente_dao.contar())),
            ("Referencias en inventario", str(self.__repuesto_repo.contar())),
            ("Valor del inventario", pesos(self.__repuesto_repo.valor_inventario())),
            ("Facturas registradas", str(self.__venta_repo.contar())),
            ("Devoluciones registradas", f"{self.__devolucion_repo.contar()} "
                                         f"({pesos(self.__devolucion_repo.total_devuelto())})"),
            ("Total vendido (neto, sin devoluciones)", pesos(self.__venta_repo.total_vendido())),
        ]
        self.tabla_indicadores.rows.clear()
        for nombre, valor in indicadores:
            self.tabla_indicadores.rows.append(ft.DataRow(cells=[celda(nombre), celda(valor)]))

        self.tabla_alertas.rows.clear()
        for r in self.__repuesto_repo.listar_stock_bajo():
            self.tabla_alertas.rows.append(ft.DataRow(cells=[
                celda(r.codigo), celda(r.nombre), celda(r.marca), celda(r.stock)]))
        self._actualizar()
