"""Pantalla CRUD de clientes."""
from __future__ import annotations

from typing import Optional

import flet as ft

from data.cliente_dao import ARCHIVADO, ClienteDAO
from data.errores import ErrorPersistencia
from domain.cliente import Cliente
from ui.components.comunes import (Colors, Icons, boton, celda, confirmar, crear_tabla, tarjeta,
                                   titulo_seccion)
from ui.components.vista_base import VistaBase


class ClientesView(VistaBase):
    def __init__(self, page: ft.Page, dao: ClienteDAO) -> None:
        self.__dao = dao
        self.__editando: Optional[Cliente] = None
        super().__init__(page)

    def _construir(self) -> ft.Control:
        self.txt_documento = ft.TextField(label="Documento *", width=180,
                                          keyboard_type=ft.KeyboardType.NUMBER)
        self.txt_nombre = ft.TextField(label="Nombre completo *", width=260)
        self.txt_telefono = ft.TextField(label="Teléfono", width=170,
                                         keyboard_type=ft.KeyboardType.PHONE)
        self.txt_email = ft.TextField(label="Correo", width=230)
        self.txt_placa = ft.TextField(label="Placa vehículo", width=150)
        self.lbl_modo = ft.Text("Nuevo cliente", weight=ft.FontWeight.BOLD)
        self.txt_buscar = ft.TextField(label="Buscar por nombre, documento o placa",
                                       prefix_icon=Icons.SEARCH, width=380,
                                       on_change=lambda e: self.refrescar())
        self.tabla = crear_tabla(["ID", "Documento", "Nombre", "Teléfono", "Correo", "Placa", "Acciones"])

        formulario = ft.Column([
            self.lbl_modo,
            ft.Row([self.txt_documento, self.txt_nombre, self.txt_telefono], wrap=True),
            ft.Row([self.txt_email, self.txt_placa], wrap=True),
            ft.Row([
                boton("Guardar", Icons.SAVE, self._guardar),
                boton("Limpiar", Icons.CLEAR, lambda e: self._limpiar(), secundario=True),
            ]),
        ])
        listado = ft.Column([
            self.txt_buscar,
            ft.Column([ft.Row([self.tabla], scroll=ft.ScrollMode.AUTO)],
                      scroll=ft.ScrollMode.AUTO, expand=True),
        ], expand=True)
        return ft.Column([
            titulo_seccion("Clientes", Icons.PEOPLE),
            tarjeta(formulario),
            tarjeta(listado, expand=True),
        ], expand=True)

    # ----- Lectura -----
    def refrescar(self) -> None:
        self.tabla.rows.clear()
        for c in self.__dao.listar(self.txt_buscar.value or ""):
            self.tabla.rows.append(ft.DataRow(cells=[
                celda(c.id), celda(c.documento), celda(c.nombre), celda(c.telefono),
                celda(c.email), celda(c.placa_vehiculo),
                ft.DataCell(content=ft.Row([
                    ft.IconButton(icon=Icons.EDIT, icon_color=Colors.BLUE_600, tooltip="Editar",
                                  on_click=lambda e, cli=c: self._cargar(cli)),
                    ft.IconButton(icon=Icons.DELETE, icon_color=Colors.RED_600, tooltip="Eliminar",
                                  on_click=lambda e, cli=c: self._eliminar(cli)),
                ], spacing=0)),
            ]))
        self._actualizar()

    # ----- Crear / Actualizar -----
    def _guardar(self, e) -> None:
        try:
            if self.__editando is None:
                cliente = Cliente(self.txt_documento.value, self.txt_nombre.value,
                                  self.txt_telefono.value, self.txt_email.value, self.txt_placa.value)
                self.__dao.crear(cliente)
                self._ok(f"Cliente {cliente.nombre} registrado")
            else:
                c = self.__editando
                c.documento = self.txt_documento.value
                c.nombre = self.txt_nombre.value
                c.telefono = self.txt_telefono.value
                c.email = self.txt_email.value
                c.placa_vehiculo = self.txt_placa.value
                self.__dao.actualizar(c)
                self._ok(f"Cliente {c.nombre} actualizado")
            self._limpiar()
        except (ValueError, ErrorPersistencia) as ex:
            self._error(str(ex))

    def _cargar(self, cliente: Cliente) -> None:
        self.__editando = cliente
        self.txt_documento.value = cliente.documento
        self.txt_nombre.value = cliente.nombre
        self.txt_telefono.value = cliente.telefono
        self.txt_email.value = cliente.email
        self.txt_placa.value = cliente.placa_vehiculo
        self.lbl_modo.value = f"Editando cliente #{cliente.id}"
        self._actualizar()

    def _limpiar(self) -> None:
        self.__editando = None
        for campo in (self.txt_documento, self.txt_nombre, self.txt_telefono,
                      self.txt_email, self.txt_placa):
            campo.value = ""
        self.lbl_modo.value = "Nuevo cliente"
        self.refrescar()

    # ----- Eliminar -----
    def _eliminar(self, cliente: Cliente) -> None:
        def ejecutar() -> None:
            try:
                resultado = self.__dao.eliminar(cliente.id)
                if resultado == ARCHIVADO:
                    self._ok(f"{cliente.nombre} tiene facturas: se archivó y su historial se conserva")
                else:
                    self._ok("Cliente eliminado")
                self._limpiar()
            except ErrorPersistencia as ex:
                self._error(str(ex))

        confirmar(self._page, "Eliminar cliente",
                  f"¿Eliminar a {cliente}?\nSi ya tiene facturas, se archivará: deja de aparecer "
                  "en las listas, pero sus facturas se conservan.", ejecutar)
